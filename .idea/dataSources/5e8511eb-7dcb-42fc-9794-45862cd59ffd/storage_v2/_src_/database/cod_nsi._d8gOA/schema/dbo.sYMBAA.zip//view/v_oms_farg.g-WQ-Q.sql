CREATE VIEW [V_oms_FARG] AS SELECT 
[hDED].[FARGID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FARGTreeID] as [rf_FARGTreeID], 
[hDED].[C_FARG] as [C_FARG], 
[hDED].[FNAME_FRG] as [FNAME_FRG], 
[hDED].[SNAME_FRG] as [SNAME_FRG], 
[hDED].[MSG_TEXT] as [MSG_TEXT]
FROM [oms_FARG] as [hDED]
go

