

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetRefValue]
	@txt varchar(250),
	@dtdid int,
	@id	varchar(10),
	@Result varchar(max) output	
AS
BEGIN
	
	IF (Left(@txt, 1) != '#' or Right(@txt, 1) != '#' or len(@txt) <= 2) RETURN ''
	/* Результат */
	DECLARE @ResultVar varchar(max)
	
	/* Имя таблицы, ПК */
	DECLARE @tbName varchar(50), @fldName varchar(50)	
	SELECT @tbName  = [headTable], @fldName=PK_Name from x_docTypeDef where docTypeDefID = @dtdid

	/* Позиция разделителя */
	DECLARE  @divInd int 
	SET @divInd = charindex('.', @txt)
	
	/* Выбираемый элемент */
	DECLARE @selElem varchar(250)
	DECLARE @dtFormat varchar(10)
	SET @dtFormat = ''

	IF (@divInd != 0) 
		BEGIN
			/* Просто поле */		
			SET @selElem = substring(@txt, 2, @divInd - 2)		
		END
	ELSE
		BEGIN		
			/* Ссылочное поле */
			SET @selElem =  replace(@txt, '#', '')
		END	
	
	
	/*Используем формат даты*/
	if (isnull((select top 1 ValueType from x_docElemDef WHERE DocTypeDefID = @dtdid AND FieldName = @selElem), 0) = 5)
		SET @dtFormat = ', 104'

	/* Команда выбора данных */
	DECLARE @cmd nvarchar(4000)	
	SET @cmd = 'select @res1=convert(varchar(max), ' + @selElem + @dtFormat + ')  from ' + @tbName + 
			   ' where cast(' +  @fldName + ' as varchar(10))  = ''' + @id + ''''
	EXEC sp_executesql @cmd, N'@res1 varchar(255) out', @res1 = @ResultVar out 	
	print @cmd
	/*Выбирали конечный элемент - выходим */
	IF (@divInd = 0) 
	BEGIN
		SET @Result = @ResultVar
		RETURN 0
	END

	/* Выбирали ссылочный документ. Определяем новый доктип */
	DECLARE @newDTDID int 
	SELECT @newDTDID = linkedDocTypeDefID FROM x_docElemDef 
		WHERE DocTypeDefID = @dtdid AND FieldName = @selElem

	/* Новый запрос */
	SET @selElem = '#' +  right(@txt, len(@txt) - @divInd )	

	DECLARE	@return_value int
	DECLARE	@refResult varchar(max)

	EXEC	@return_value = [dbo].[GetRefValue]
			@txt = @selElem,
			@dtdid = @newDTDID,
			@id = @ResultVar,
			@Result = @refResult OUTPUT
	
	SET @Result = @refResult
	RETURN @return_value
END


go

