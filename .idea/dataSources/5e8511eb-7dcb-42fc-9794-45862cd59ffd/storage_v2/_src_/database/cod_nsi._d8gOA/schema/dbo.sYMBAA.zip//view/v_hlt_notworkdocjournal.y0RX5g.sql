CREATE VIEW [V_hlt_NotWorkDocJournal] AS SELECT 
[hDED].[NotWorkDocJournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_NotWorkDocID] as [rf_NotWorkDocID], 
[jT_hlt_NotWorkDoc].[V_NWDS] as [SILENT_rf_NotWorkDocID], 
[hDED].[ResponseCode] as [ResponseCode], 
[hDED].[Response] as [Response], 
[hDED].[Comment] as [Comment], 
[hDED].[ActionDate] as [ActionDate], 
[hDED].[Flags] as [Flags], 
[hDED].[Status] as [Status]
FROM [hlt_NotWorkDocJournal] as [hDED]
INNER JOIN [V_hlt_NotWorkDoc] as [jT_hlt_NotWorkDoc] on [jT_hlt_NotWorkDoc].[NotWorkDocID] = [hDED].[rf_NotWorkDocID]
go

