CREATE VIEW [V_oms_PRVD] AS SELECT 
[hDED].[PRVDID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_PRVD] as [C_PRVD], 
[hDED].[NAME] as [NAME], 
[hDED].[Date_B] as [Date_B], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[Date_E] as [Date_E]
FROM [oms_PRVD] as [hDED]
go

