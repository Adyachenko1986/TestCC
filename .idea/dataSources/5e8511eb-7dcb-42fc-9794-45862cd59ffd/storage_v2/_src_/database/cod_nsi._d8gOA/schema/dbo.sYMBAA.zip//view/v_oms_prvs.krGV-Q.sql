CREATE VIEW [V_oms_PRVS] AS SELECT 
[hDED].[PRVSID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_PRVS].[C_PRVS] as [V_Main_C_PRVS], 
[hDED].[rf_MainPRVSID] as [rf_MainPRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_MainPRVSID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[I_PRVS] as [I_PRVS], 
[hDED].[C_PRVS] as [C_PRVS], 
[hDED].[Date_Beg] as [Date_Beg], 
[hDED].[PRVS_NAME] as [PRVS_NAME], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[Date_End] as [Date_End]
FROM [oms_PRVS] as [hDED]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_MainPRVSID]
go

