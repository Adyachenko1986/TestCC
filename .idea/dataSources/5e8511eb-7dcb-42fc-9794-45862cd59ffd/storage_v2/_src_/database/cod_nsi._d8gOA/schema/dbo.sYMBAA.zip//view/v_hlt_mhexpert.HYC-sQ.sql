CREATE VIEW [V_hlt_MHExpert] AS SELECT 
[hDED].[MHExpertID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ExpertTypeID] as [rf_ExpertTypeID], 
[jT_oms_ExpertType].[Name] as [SILENT_rf_ExpertTypeID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[Num] as [Num], 
[hDED].[DateExpert] as [DateExpert], 
[hDED].[DateIn] as [DateIn], 
[hDED].[Sum_O] as [Sum_O], 
[hDED].[Kol_O] as [Kol_O], 
[hDED].[Description] as [Description], 
[hDED].[User] as [User], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_MHExpert] as [hDED]
INNER JOIN [oms_ExpertType] as [jT_oms_ExpertType] on [jT_oms_ExpertType].[ExpertTypeID] = [hDED].[rf_ExpertTypeID]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
go

