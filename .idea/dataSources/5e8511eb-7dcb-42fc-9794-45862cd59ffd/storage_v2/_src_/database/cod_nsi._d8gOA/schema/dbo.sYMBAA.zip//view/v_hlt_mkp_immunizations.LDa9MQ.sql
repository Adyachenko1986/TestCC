CREATE VIEW [V_hlt_mkp_Immunizations] AS SELECT 
[hDED].[mkp_ImmunizationsID], [hDED].[x_Edition], [hDED].[x_Status], 
([hded].Code+  ' - '+ [hded].Name) as [V_Descr], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Name] as [Name], 
[hDED].[FullName] as [FullName], 
[hDED].[VaccineGroup] as [VaccineGroup], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_mkp_Immunizations] as [hDED]
go

