CREATE VIEW [V_oms_kl_Sanitation] AS SELECT 
[hDED].[kl_SanitationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags]
FROM [oms_kl_Sanitation] as [hDED]
go

