CREATE VIEW [V_rls_Prep_Iic] AS SELECT 
[hDED].[Prep_IicID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsIicUID] as [rf_ClsIicUID], 
[hDED].[rf_ClsPharmaGroupUID] as [rf_ClsPharmaGroupUID], 
[hDED].[rf_PrepUID] as [rf_PrepUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Prep_Iic] as [hDED]
go

