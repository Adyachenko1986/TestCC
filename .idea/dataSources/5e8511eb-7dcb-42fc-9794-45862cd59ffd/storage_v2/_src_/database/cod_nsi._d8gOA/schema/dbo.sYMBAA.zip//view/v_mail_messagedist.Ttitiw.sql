CREATE VIEW [V_mail_MessageDist] AS SELECT 
[hDED].[MessageDistID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MessageID] as [rf_MessageID], 
[hDED].[rf_MessageStateID] as [rf_MessageStateID], 
[hDED].[rf_HostsID] as [rf_HostsID]
FROM [mail_MessageDist] as [hDED]
go

