CREATE VIEW  [dbo].[sl_doctors] AS

 select 
    mcod             as mcod
     ,PCOD             as pcod
     ,FAM_V             as fam_v
     ,IM_V             as im_v
     ,OT_V             as ot_v
     ,d.DATE_B         as date_b
     ,d.DATE_E         as date_e
     ,1                 as isfed
     ,0                 as isreg
     ,ISNULL((rf_TypeDoctorListID ),0) as is7n
     ,0                  as pk_doc
     ,C_OGRN             as c_ogrn

 
  from oms_doctor  d
  inner join oms_LPU on LPUID=d.rf_LPUID
  left join oms_DoctorList on rf_DoctorID=d.DOCTORID
    where doctorID<>0
go

