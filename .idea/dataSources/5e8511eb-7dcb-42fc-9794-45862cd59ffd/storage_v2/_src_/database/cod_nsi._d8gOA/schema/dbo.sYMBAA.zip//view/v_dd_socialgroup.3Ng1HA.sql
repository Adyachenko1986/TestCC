CREATE VIEW [V_dd_SocialGroup] AS SELECT 
[hDED].[SocialGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flags] as [Flags]
FROM [dd_SocialGroup] as [hDED]
go

