CREATE VIEW [V_ras_PositionRTC] AS SELECT 
[hDED].[PositionRTCID], [hDED].[HostPositionRTCID], [hDED].[x_Edition], [hDED].[x_Status], 
dbo.ras_ConvertToFraction(hDED.Count,(select top 1 Severability1 * Severability2  from ras_Nomenclature nom where jT_ras_StoredLS.rf_NomenclatureID = nom.NomenclatureID and jT_ras_StoredLS.rf_NomenclatureIDHost = nom.HostNomenclatureID)) as [V_FractionCount], 
[jT_ras_StoredLS].[V_TenderNum] as [V_TenderNum], 
[jT_ras_StoredLS].[V_Owner] as [V_Owner], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_PharmacyRecipeID] as [rf_PharmacyRecipeID], 
[hDED].[rf_StatePositionReportID] as [rf_StatePositionReportID], 
[hDED].[rf_StateSenderPositionReportID] as [rf_StateSenderPositionReportID], 
[hDED].[rf_StateExpertPositionReportID] as [rf_StateExpertPositionReportID], 
[hDED].[rf_ReportToComitentID] as [rf_ReportToComitentID], 
[hDED].[rf_ReportToComitentIDHost] as [rf_ReportToComitentIDHost], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[Count] as [Count], 
[hDED].[Price] as [Price], 
[hDED].[Summa] as [Summa], 
[hDED].[Reward] as [Reward], 
[hDED].[RecipeGUID] as [RecipeGUID], 
[hDED].[IsMinus] as [IsMinus]
FROM [ras_PositionRTC] as [hDED]
INNER JOIN [V_ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
go

