CREATE VIEW [V_dd_DDPhisicalDeviation] AS SELECT 
[hDED].[DDPhisicalDeviationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDPhisicalDeveopmentID] as [rf_DDPhisicalDeveopmentID], 
[hDED].[rf_DDPhisicalDeviationTypeGUID] as [rf_DDPhisicalDeviationTypeGUID], 
[jT_dd_DDPhisicalDeviationType].[Name] as [SILENT_rf_DDPhisicalDeviationTypeGUID], 
[hDED].[Flag] as [Flag]
FROM [dd_DDPhisicalDeviation] as [hDED]
INNER JOIN [dd_DDPhisicalDeviationType] as [jT_dd_DDPhisicalDeviationType] on [jT_dd_DDPhisicalDeviationType].[UGUID] = [hDED].[rf_DDPhisicalDeviationTypeGUID]
go

