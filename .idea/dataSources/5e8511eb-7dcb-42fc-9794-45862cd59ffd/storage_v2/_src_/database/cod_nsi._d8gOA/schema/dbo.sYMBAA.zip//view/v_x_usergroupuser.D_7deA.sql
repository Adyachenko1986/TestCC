
CREATE VIEW [dbo].[V_x_UserGroupUser] AS SELECT 
[hDED].[UserGroupUserID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_UserGUID] as [rf_UserGUID], 
[jT_x_User].[GeneralLogin] as [SILENT_rf_UserGUID], 
[hDED].[rf_UserGroupGUID] as [rf_UserGroupGUID]
FROM [x_UserGroupUser] as [hDED]
INNER JOIN [x_User] as [jT_x_User] on [jT_x_User].[GUID] = [hDED].[rf_UserGUID]
go

