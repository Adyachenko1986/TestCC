CREATE VIEW [V_dd_RiskFactors] AS SELECT 
[hDED].[RiskFactorsID], [hDED].[x_Edition], [hDED].[x_Status], 
((((case [Value]
	when  1 then 'Да' 
	when  2 then 'Нет' 
	when  3 then 'Неизвестно' when  0 then 'Неизвестно'
 end)))) as [V_Value], 
[jT_dd_HealthIndex].[HealthIndexName] as [V_HealthIndexName], 
[hDED].[rf_DDFormGUID] as [rf_DDFormGUID], 
[hDED].[rf_HealthIndexUGUID] as [rf_HealthIndexUGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Value] as [Value]
FROM [dd_RiskFactors] as [hDED]
INNER JOIN [dd_HealthIndex] as [jT_dd_HealthIndex] on [jT_dd_HealthIndex].[UGUID] = [hDED].[rf_HealthIndexUGUID]
go

