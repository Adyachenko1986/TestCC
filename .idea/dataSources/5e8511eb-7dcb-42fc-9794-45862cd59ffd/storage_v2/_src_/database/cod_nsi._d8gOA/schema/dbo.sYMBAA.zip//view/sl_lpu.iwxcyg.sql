CREATE VIEW [dbo].[sl_Lpu] AS 

select 
LPUID         as idlpu    
,1			 AS actual    	
--FLAGS         as actual    
,MCOD         as mcod    
,C_OGRN         as c_ogrn    
,M_NAMES     as m_names    
,c_OKATO     as region    
,ADRES         as adres    
,DATE_B         as date_b    
,DATE_E         as date_e    
,DATE_B         as dt_create    
,''             as dt_drop    
,''             as dt_lock    
,''             as dt_publish    
,'0'         as idUser_create    
,'0'         as idUser_deactual

 from Oms_LPU
 inner join OMS_OKATO on rf_OKATOID=OKATOID
where  LPUID>0 and DATE_E >getdate()
go

