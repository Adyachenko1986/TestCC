CREATE VIEW [V_hlt_BlankTemplateType] AS SELECT 
[hDED].[BlankTemplateTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_BlankTemplateTypeID] as [rf_BlankTemplateTypeID], 
[jT_hlt_BlankTemplateType].[Name] as [SILENT_rf_BlankTemplateTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [hlt_BlankTemplateType] as [hDED]
INNER JOIN [hlt_BlankTemplateType] as [jT_hlt_BlankTemplateType] on [jT_hlt_BlankTemplateType].[BlankTemplateTypeID] = [hDED].[rf_BlankTemplateTypeID]
go

