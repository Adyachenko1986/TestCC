CREATE VIEW [V_hlt_DocBusyType] AS SELECT 
[hDED].[DocBusyTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[Name] as [Name], 
[hDED].[Color] as [Color], 
[hDED].[TypeBusy] as [TypeBusy], 
[hDED].[DateB] as [DateB], 
[hDED].[DateE] as [DateE]
FROM [hlt_DocBusyType] as [hDED]
go

