CREATE VIEW [V_dd_StatusDD] AS SELECT 
[hDED].[StatusDDID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID]
FROM [dd_StatusDD] as [hDED]
go

