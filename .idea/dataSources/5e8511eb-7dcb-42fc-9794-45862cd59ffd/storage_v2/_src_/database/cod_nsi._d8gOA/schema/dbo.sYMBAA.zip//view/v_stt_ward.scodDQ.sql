CREATE VIEW [V_stt_Ward] AS SELECT 
[hDED].[WardID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_WardTypeID] as [rf_WardTypeID], 
[jT_stt_WardType].[Name] as [SILENT_rf_WardTypeID], 
[hDED].[rf_ComfortClassID] as [rf_ComfortClassID], 
[jT_stt_ComfortClass].[Name] as [SILENT_rf_ComfortClassID], 
[hDED].[rf_GenderTypeID] as [rf_GenderTypeID], 
[jT_stt_GenderType].[Gender] as [SILENT_rf_GenderTypeID], 
[hDED].[Num] as [Num], 
[hDED].[BedCount] as [BedCount], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [stt_Ward] as [hDED]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_WardType] as [jT_stt_WardType] on [jT_stt_WardType].[WardTypeID] = [hDED].[rf_WardTypeID]
INNER JOIN [stt_ComfortClass] as [jT_stt_ComfortClass] on [jT_stt_ComfortClass].[ComfortClassID] = [hDED].[rf_ComfortClassID]
INNER JOIN [stt_GenderType] as [jT_stt_GenderType] on [jT_stt_GenderType].[GenderTypeID] = [hDED].[rf_GenderTypeID]
go

