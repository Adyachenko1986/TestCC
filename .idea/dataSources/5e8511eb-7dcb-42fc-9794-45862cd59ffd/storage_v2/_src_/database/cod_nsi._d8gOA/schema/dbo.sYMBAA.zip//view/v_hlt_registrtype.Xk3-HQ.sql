CREATE VIEW [V_hlt_RegistrType] AS SELECT 
[hDED].[RegistrTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_BlankTemplateID] as [rf_BlankTemplateID], 
[jT_hlt_BlankTemplate].[Caption] as [SILENT_rf_BlankTemplateID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[GUID] as [GUID]
FROM [hlt_RegistrType] as [hDED]
INNER JOIN [hlt_BlankTemplate] as [jT_hlt_BlankTemplate] on [jT_hlt_BlankTemplate].[BlankTemplateID] = [hDED].[rf_BlankTemplateID]
go

