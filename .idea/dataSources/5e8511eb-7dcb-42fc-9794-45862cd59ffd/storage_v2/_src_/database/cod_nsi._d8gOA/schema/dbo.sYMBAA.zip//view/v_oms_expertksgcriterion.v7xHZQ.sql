CREATE VIEW [V_oms_ExpertKSGCriterion] AS SELECT 
[hDED].[ExpertKSGCriterionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[GUIDExpertKSGCriterion] as [GUIDExpertKSGCriterion], 
[hDED].[CodeKSGCriterion] as [CodeKSGCriterion], 
[hDED].[MNNKSGCriterion] as [MNNKSGCriterion], 
[hDED].[NameKSGCriterion] as [NameKSGCriterion], 
[hDED].[KolKSGCriterion] as [KolKSGCriterion], 
[hDED].[GospitKSGCriterion] as [GospitKSGCriterion], 
[hDED].[Flags] as [Flags], 
[hDED].[Rem] as [Rem]
FROM [oms_ExpertKSGCriterion] as [hDED]
go

