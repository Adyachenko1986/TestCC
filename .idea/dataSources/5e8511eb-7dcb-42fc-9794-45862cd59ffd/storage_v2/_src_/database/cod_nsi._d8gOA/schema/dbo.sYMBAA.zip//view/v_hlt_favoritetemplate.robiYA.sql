CREATE VIEW [V_hlt_FavoriteTemplate] AS SELECT 
[hDED].[FavoriteTemplateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_BlankTemplateID] as [rf_BlankTemplateID], 
[jT_hlt_BlankTemplate].[Caption] as [SILENT_rf_BlankTemplateID]
FROM [hlt_FavoriteTemplate] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_BlankTemplate] as [jT_hlt_BlankTemplate] on [jT_hlt_BlankTemplate].[BlankTemplateID] = [hDED].[rf_BlankTemplateID]
go

