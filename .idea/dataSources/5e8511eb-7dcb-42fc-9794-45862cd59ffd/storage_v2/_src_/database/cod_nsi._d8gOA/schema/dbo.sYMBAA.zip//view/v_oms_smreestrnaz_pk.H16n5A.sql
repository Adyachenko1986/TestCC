CREATE VIEW [V_oms_SMReestrNAZ_PK] AS SELECT 
[hDED].[SMReestrNAZ_PKID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[NAZ_PK] as [NAZ_PK]
FROM [oms_SMReestrNAZ_PK] as [hDED]
go

