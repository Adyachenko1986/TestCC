CREATE VIEW [dbo].[sl_sp_tov]  AS
select 	 NOMK_LS             as nomk_ls    
		,NAME_MED         as name_med    
		,NAME_FCT         as name_fct
		,TRNameID     as c_trn    
		,C_MNN     as c_mnn    
		,c_lf         as c_lf    
		,N_FV             as n_fv    
		    
		,(select 
		case when D_LS!='0' then D_LS+' '+NAME_DLS else '' end +
		case when M_LF>0 then ' / '+convert(varchar,cast (M_LF as float))+' '+NAME_MLF else '' end +
		case when V_LF>0 then ' / '+convert(varchar,cast (V_LF as float))+' '+NAME_VLF else ''end +
		case when N_DOZA>0 then ' / '+convert(varchar,N_DOZa)+' доз' else '' end +
		case when N_FV>0 then ' № '+convert(varchar,N_FV) else '' end )         as doz_lf
		,NULL [c_mnndoz]
		,0 [torg_ls]
		,NULL [code_ls]
		,NULL [ko_lim]


	from oms_LS 
	inner join oms_MNName on mnnameID=rf_MNNAmeID
	inner join oms_TRName on TRNameID=rf_TRNameID
	inner join oms_DLS on DLSID=rf_DLSID
	inner join oms_LF on LFID=rf_LFID
	inner join oms_VLF on rf_VLFID = VLFID
	inner join oms_MLF on rf_MLFID = MLFID

	where LSID>0
/*

,[c_mnndoz]
      ,[torg_ls]
      ,[code_ls]
      ,[ko_lim]

*/
go

