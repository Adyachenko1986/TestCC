CREATE VIEW [V_oms_mn_OnlineDocument] AS SELECT 
[hDED].[mn_OnlineDocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_mn_DocLPUID] as [rf_mn_DocLPUID], 
[hDED].[rf_mn_JournalID] as [rf_mn_JournalID], 
[hDED].[SourceGuid] as [SourceGuid], 
[hDED].[SourceId] as [SourceId], 
[hDED].[MCOD] as [MCOD], 
[hDED].[ChangeDate] as [ChangeDate], 
[hDED].[LoadDate] as [LoadDate], 
[hDED].[IsLoad] as [IsLoad]
FROM [oms_mn_OnlineDocument] as [hDED]
go

