CREATE VIEW [V_dd_Organization] AS SELECT 
[hDED].[OrganizationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[PhoneNumber] as [PhoneNumber], 
[hDED].[Address] as [Address], 
[hDED].[Inn] as [Inn], 
[hDED].[OGRN] as [OGRN], 
[hDED].[LeaderPost] as [LeaderPost], 
[hDED].[LeaderEmail] as [LeaderEmail], 
[hDED].[LeaderFio] as [LeaderFio], 
[hDED].[LeaderPhone] as [LeaderPhone], 
[hDED].[ResponsibleFio] as [ResponsibleFio], 
[hDED].[ResponsiblePhone] as [ResponsiblePhone], 
[hDED].[ResponsibleEmail] as [ResponsibleEmail], 
[hDED].[ResponsiblePost] as [ResponsiblePost]
FROM [dd_Organization] as [hDED]
go

