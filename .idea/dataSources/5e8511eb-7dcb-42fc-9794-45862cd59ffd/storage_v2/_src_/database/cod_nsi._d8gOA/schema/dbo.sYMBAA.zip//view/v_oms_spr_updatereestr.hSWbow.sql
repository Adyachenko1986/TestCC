CREATE VIEW [V_oms_Spr_UpdateReestr] AS SELECT 
[hDED].[Spr_UpdateReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[UpdatePack_Num] as [UpdatePack_Num], 
[hDED].[Update_Date] as [Update_Date]
FROM [oms_Spr_UpdateReestr] as [hDED]
go

