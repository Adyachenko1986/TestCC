CREATE VIEW [V_ras_RReestr] AS SELECT 
[hDED].[RReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_AccountID] as [rf_AccountID], 
[hDED].[rf_ReestrTypeID] as [rf_ReestrTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[Number] as [Number], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Rem] as [Rem], 
[hDED].[Recipe_Count] as [Recipe_Count], 
[hDED].[Sum] as [Sum], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[DateIn] as [DateIn], 
[hDED].[N_SCHET] as [N_SCHET], 
[hDED].[DATE_SCHET] as [DATE_SCHET], 
[hDED].[TYPE_SCHET] as [TYPE_SCHET]
FROM [ras_RReestr] as [hDED]
go

