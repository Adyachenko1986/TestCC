CREATE VIEW [V_dd_HealthIndicators] AS SELECT 
[hDED].[HealthIndicatorsID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_dd_HealthIndex].[HealthIndexName] as [V_HealthIndexName], 
[hDED].[rf_DDFormGUID] as [rf_DDFormGUID], 
[hDED].[rf_HealthIndexUGUID] as [rf_HealthIndexUGUID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Value] as [Value], 
[hDED].[FloatValue] as [FloatValue], 
[hDED].[Flags] as [Flags]
FROM [dd_HealthIndicators] as [hDED]
INNER JOIN [dd_HealthIndex] as [jT_dd_HealthIndex] on [jT_dd_HealthIndex].[UGUID] = [hDED].[rf_HealthIndexUGUID]
go

