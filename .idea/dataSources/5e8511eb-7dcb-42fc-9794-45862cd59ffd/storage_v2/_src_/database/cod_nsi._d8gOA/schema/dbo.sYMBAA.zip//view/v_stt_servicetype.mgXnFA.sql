CREATE VIEW [V_stt_ServiceType] AS SELECT 
[hDED].[ServiceTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[flag] as [flag]
FROM [stt_ServiceType] as [hDED]
go

