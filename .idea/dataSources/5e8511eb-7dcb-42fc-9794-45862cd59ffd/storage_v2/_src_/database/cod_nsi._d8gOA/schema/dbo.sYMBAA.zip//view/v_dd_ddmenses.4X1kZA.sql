CREATE VIEW [V_dd_DDMenses] AS SELECT 
[hDED].[DDMensesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDSexualDevelopmentID] as [rf_DDSexualDevelopmentID], 
[jT_dd_DDSexualDevelopment].[rf_DDChildFormID] as [SILENT_rf_DDSexualDevelopmentID], 
[hDED].[rf_DDMensesTypeGUID] as [rf_DDMensesTypeGUID], 
[jT_dd_DDMensesType].[Name] as [SILENT_rf_DDMensesTypeGUID]
FROM [dd_DDMenses] as [hDED]
INNER JOIN [dd_DDSexualDevelopment] as [jT_dd_DDSexualDevelopment] on [jT_dd_DDSexualDevelopment].[DDSexualDevelopmentID] = [hDED].[rf_DDSexualDevelopmentID]
INNER JOIN [dd_DDMensesType] as [jT_dd_DDMensesType] on [jT_dd_DDMensesType].[UGUID] = [hDED].[rf_DDMensesTypeGUID]
go

