CREATE VIEW [V_ras_StatePositionOrder] AS SELECT 
[hDED].[StatePositionOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_StatePositionOrder] as [hDED]
go

