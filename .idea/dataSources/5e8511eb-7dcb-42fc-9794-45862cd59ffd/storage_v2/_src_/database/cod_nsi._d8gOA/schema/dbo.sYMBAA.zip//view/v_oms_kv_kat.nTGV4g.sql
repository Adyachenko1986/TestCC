CREATE VIEW [V_oms_KV_KAT] AS SELECT 
[hDED].[KV_KATID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[KVKAT] as [KVKAT], 
[hDED].[KV_KAT_NAME] as [KV_KAT_NAME]
FROM [oms_KV_KAT] as [hDED]
go

