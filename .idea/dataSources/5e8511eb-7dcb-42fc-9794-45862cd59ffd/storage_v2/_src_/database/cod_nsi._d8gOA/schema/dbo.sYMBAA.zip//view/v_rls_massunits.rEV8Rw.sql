CREATE VIEW [V_rls_MassUnits] AS SELECT 
[hDED].[MassUnitsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[FullName] as [FullName], 
[hDED].[UID] as [UID], 
[hDED].[ShortName] as [ShortName], 
[hDED].[Code] as [Code]
FROM [rls_MassUnits] as [hDED]
go

