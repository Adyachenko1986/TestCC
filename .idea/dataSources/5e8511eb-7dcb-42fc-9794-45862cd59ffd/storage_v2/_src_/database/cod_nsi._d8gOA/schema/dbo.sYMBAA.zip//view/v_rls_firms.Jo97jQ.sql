CREATE VIEW [V_rls_Firms] AS SELECT 
[hDED].[FirmsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CountriesUID] as [rf_CountriesUID], 
[hDED].[rf_FirmNamesUID] as [rf_FirmNamesUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[FullName] as [FullName], 
[hDED].[ArdMain] as [ArdMain], 
[hDED].[AdrRussia] as [AdrRussia], 
[hDED].[UID] as [UID], 
[hDED].[AdrUssr] as [AdrUssr], 
[hDED].[Code] as [Code]
FROM [rls_Firms] as [hDED]
go

