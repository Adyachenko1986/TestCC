CREATE VIEW [V_stt_ReestrMKSB] AS SELECT 
[hDED].[ReestrMKSBID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [SILENT_rf_MigrationPatientID], 
[hDED].[rf_MedServicePatientID] as [rf_MedServicePatientID], 
[jT_stt_MedServicePatient].[V_ServiceMedicalCode] as [SILENT_rf_MedServicePatientID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[jT_stt_MedicalHistory].[FIO] as [SILENT_rf_MedicalHistoryID], 
[hDED].[rf_ServiceTypeID] as [rf_ServiceTypeID], 
[jT_stt_ServiceType].[Name] as [SILENT_rf_ServiceTypeID], 
[hDED].[rf_ReestrOccasionID] as [rf_ReestrOccasionID], 
[jT_stt_ReestrOccasion].[Num] as [SILENT_rf_ReestrOccasionID], 
[hDED].[flag] as [flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Num] as [Num], 
[hDED].[Sum_V] as [Sum_V], 
[hDED].[Sum_O] as [Sum_O], 
[hDED].[Kol_V] as [Kol_V], 
[hDED].[Kol_O] as [Kol_O], 
[hDED].[NumRepPer] as [NumRepPer]
FROM [stt_ReestrMKSB] as [hDED]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATOID]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
INNER JOIN [V_stt_MedServicePatient] as [jT_stt_MedServicePatient] on [jT_stt_MedServicePatient].[MedServicePatientID] = [hDED].[rf_MedServicePatientID]
INNER JOIN [V_stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [stt_ServiceType] as [jT_stt_ServiceType] on [jT_stt_ServiceType].[ServiceTypeID] = [hDED].[rf_ServiceTypeID]
INNER JOIN [stt_ReestrOccasion] as [jT_stt_ReestrOccasion] on [jT_stt_ReestrOccasion].[ReestrOccasionID] = [hDED].[rf_ReestrOccasionID]
go

