CREATE VIEW [V_hlt_OperationEquipment] AS SELECT 
[hDED].[OperationEquipmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_OperationEquipmentTypeID] as [rf_kl_OperationEquipmentTypeID], 
[jT_oms_kl_OperationEquipmentType].[Code] as [SILENT_rf_kl_OperationEquipmentTypeID], 
[hDED].[rf_OperationID] as [rf_OperationID], 
[jT_hlt_Operation].[V_OperationTypeName] as [SILENT_rf_OperationID], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_OperationEquipment] as [hDED]
INNER JOIN [oms_kl_OperationEquipmentType] as [jT_oms_kl_OperationEquipmentType] on [jT_oms_kl_OperationEquipmentType].[kl_OperationEquipmentTypeID] = [hDED].[rf_kl_OperationEquipmentTypeID]
INNER JOIN [V_hlt_Operation] as [jT_hlt_Operation] on [jT_hlt_Operation].[OperationID] = [hDED].[rf_OperationID]
go

