CREATE VIEW [V_hlt_Disability] AS SELECT 
[hDED].[DisabilityID], [hDED].[x_Edition], [hDED].[x_Status], 
((case  [hDED].DisabilityStatus WHEN 0 THEN 'Не указано' WHEN 1 THEN 'Впервые' WHEN 2 THEN 'Повторно' ELSE '' END)) as [V_DisabilityStatus], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_INVID] as [rf_INVID], 
[jT_hlt_INV].[NAME] as [SILENT_rf_INVID], 
[hDED].[rf_kl_ReasonInvID] as [rf_kl_ReasonInvID], 
[jT_oms_kl_ReasonInv].[Name] as [SILENT_rf_kl_ReasonInvID], 
[hDED].[NameDoc] as [NameDoc], 
[hDED].[S_Doc] as [S_Doc], 
[hDED].[N_Doc] as [N_Doc], 
[hDED].[DocIssuedBy] as [DocIssuedBy], 
[hDED].[DateDoc] as [DateDoc], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[DisabilityStatus] as [DisabilityStatus]
FROM [hlt_Disability] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_INV] as [jT_hlt_INV] on [jT_hlt_INV].[INVID] = [hDED].[rf_INVID]
INNER JOIN [oms_kl_ReasonInv] as [jT_oms_kl_ReasonInv] on [jT_oms_kl_ReasonInv].[kl_ReasonInvID] = [hDED].[rf_kl_ReasonInvID]
go

