CREATE VIEW [V_hlt_UchastokMKAB] AS SELECT 
[hDED].[UchastokMKABID], [hDED].[x_Edition], [hDED].[x_Status], 
((((case  [hDED].AttachKind WHEN 0 THEN '' WHEN 1 THEN 'Прикрепление к МО и специалисту' WHEN 2 THEN 'Прикрепление к специалисту' WHEN 3 THEN 'Смена специалиста на участке' WHEN 99 THEN 'Открепление' ELSE '' END)))) as [V_AttachKind], 
(isnull((select rtrim(ltrim(family + ' ' + name + ' ' + ot)) from hlt_MKAB where MKABID = [hDED].rf_MKABID), '')) as [V_FIO], 
((isnull((select '[' + ltrim(rtrim(PCOD)) + '] '+ 
Upper(substring(ltrim(FAM_V), 1, 1))+ CASE WHEN 
LEN(FAM_V) > 0  THEN 
LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, 
LEN(LTRIM(RTRIM(FAM_V))) - 1))  ELSE '' END + ' '  + 
Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + 
Upper(substring(ltrim(OT_V), 1, 1)) + '.' from hlt_LPUDoctor where LPUDoctorID = [hDed].rf_LPUDoctorID), ''))) as [V_DoctorInfo], 
[jT_hlt_Uchastok].[UchastoCaption] as [V_UchastokName], 
[hDED].[rf_NextLpuID] as [rf_NextLpuID], 
[hDED].[rf_PrevLpuID] as [rf_PrevLpuID], 
[hDED].[rf_RefusalID] as [rf_RefusalID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_RefusalID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[jT_hlt_Uchastok].[CODE] as [SILENT_rf_UchastokID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_TypeAttachmentID] as [rf_TypeAttachmentID], 
[jT_hlt_TypeAttachment].[Name] as [SILENT_rf_TypeAttachmentID], 
[hDED].[rf_MainUchastokMKABID] as [rf_MainUchastokMKABID], 
[hDED].[rf_RepresentativeMKABID] as [rf_RepresentativeMKABID], 
[hDED].[rf_DetachReasonID] as [rf_DetachReasonID], 
[hDED].[rf_kl_AttachmentStatusID] as [rf_kl_AttachmentStatusID], 
[jT_oms_kl_AttachmentStatus].[Name] as [SILENT_rf_kl_AttachmentStatusID], 
[hDED].[DateIn] as [DateIn], 
[hDED].[DateOut] as [DateOut], 
[hDED].[isDetach] as [isDetach], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[NextLPU] as [NextLPU], 
[hDED].[PrevLPU] as [PrevLPU], 
[hDED].[DateConfirm] as [DateConfirm], 
[hDED].[DocumentNum] as [DocumentNum], 
[hDED].[DocumentDate] as [DocumentDate], 
[hDED].[isCurrent] as [isCurrent], 
[hDED].[AttachKind] as [AttachKind]
FROM [hlt_UchastokMKAB] as [hDED]
INNER JOIN [hlt_Uchastok] as [jT_hlt_Uchastok] on [jT_hlt_Uchastok].[UchastokID] = [hDED].[rf_UchastokID]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_RefusalID]
INNER JOIN [hlt_TypeAttachment] as [jT_hlt_TypeAttachment] on [jT_hlt_TypeAttachment].[TypeAttachmentID] = [hDED].[rf_TypeAttachmentID]
INNER JOIN [oms_kl_AttachmentStatus] as [jT_oms_kl_AttachmentStatus] on [jT_oms_kl_AttachmentStatus].[kl_AttachmentStatusID] = [hDED].[rf_kl_AttachmentStatusID]
go

