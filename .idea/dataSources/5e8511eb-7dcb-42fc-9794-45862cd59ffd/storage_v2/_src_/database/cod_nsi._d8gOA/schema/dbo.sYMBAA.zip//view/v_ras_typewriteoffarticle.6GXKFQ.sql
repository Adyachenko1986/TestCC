CREATE VIEW [V_ras_TypeWriteOffArticle] AS SELECT 
[hDED].[TypeWriteOffArticleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [ras_TypeWriteOffArticle] as [hDED]
go

