CREATE VIEW [V_rls_Prep_ActMatters] AS SELECT 
[hDED].[Prep_ActMattersID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ActMattersUID] as [rf_ActMattersUID], 
[hDED].[rf_PrepUID] as [rf_PrepUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Prep_ActMatters] as [hDED]
go

