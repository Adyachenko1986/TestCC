CREATE VIEW [V_hlt_Applicability] AS SELECT 
[hDED].[ApplicabilityID], [hDED].[x_Edition], [hDED].[x_Status], 
((( 'От ' + convert(varchar, convert(int, [hded].AgeFrom)) + ' до '+ convert(varchar, convert(int, [hded].AgeTo))))) as [V_AgeFrom_AgeTo], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_BlankTemplateID] as [rf_BlankTemplateID], 
[jT_hlt_BlankTemplate].[Caption] as [SILENT_rf_BlankTemplateID], 
[hDED].[AgeFrom] as [AgeFrom], 
[hDED].[AgeTo] as [AgeTo], 
[hDED].[Flags] as [Flags]
FROM [hlt_Applicability] as [hDED]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [hlt_BlankTemplate] as [jT_hlt_BlankTemplate] on [jT_hlt_BlankTemplate].[BlankTemplateID] = [hDED].[rf_BlankTemplateID]
go

