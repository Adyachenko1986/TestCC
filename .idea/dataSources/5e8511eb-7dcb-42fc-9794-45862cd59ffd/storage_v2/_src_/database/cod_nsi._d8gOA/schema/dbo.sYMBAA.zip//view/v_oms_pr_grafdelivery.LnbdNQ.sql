CREATE VIEW [V_oms_pr_GrafDelivery] AS SELECT 
[hDED].[pr_GrafDeliveryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[DateDelivery] as [DateDelivery], 
[hDED].[Region] as [Region]
FROM [oms_pr_GrafDelivery] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

