CREATE VIEW [V_hlt_Invoice] AS SELECT 
[hDED].[InvoiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_MKAB].[V_FIO] as [V_fio], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_DiscountID] as [rf_DiscountID], 
[jT_hlt_Discount].[DiscountValue] as [SILENT_rf_DiscountID], 
[hDED].[rf_DogovorPayingID] as [rf_DogovorPayingID], 
[jT_hlt_DogovorPaying].[Num] as [SILENT_rf_DogovorPayingID], 
[hDED].[rf_DiscountReasonTypeID] as [rf_DiscountReasonTypeID], 
[jT_hlt_DiscountReasonType].[Code] as [SILENT_rf_DiscountReasonTypeID], 
[hDED].[BillSum] as [BillSum], 
[hDED].[BillFlag] as [BillFlag], 
[hDED].[Flags] as [Flags], 
[hDED].[Date] as [Date], 
[hDED].[BillDate] as [BillDate], 
[hDED].[Num] as [Num], 
[hDED].[xmlData] as [xmlData], 
[hDED].[rf_CreateUserID] as [rf_CreateUserID], 
[hDED].[CreateUserName] as [CreateUserName], 
[hDED].[rf_EditUserID] as [rf_EditUserID], 
[hDED].[EditUserName] as [EditUserName], 
[hDED].[FullSum] as [FullSum], 
[hDED].[GUID] as [GUID], 
[hDED].[DiscountDocSN] as [DiscountDocSN], 
[hDED].[DiscountDocDate] as [DiscountDocDate], 
[hDED].[DiscountComment] as [DiscountComment], 
[hDED].[Avans] as [Avans], 
[hDED].[OrderInitiator] as [OrderInitiator], 
[hDED].[CheckNum] as [CheckNum]
FROM [hlt_Invoice] as [hDED]
INNER JOIN [V_hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_Discount] as [jT_hlt_Discount] on [jT_hlt_Discount].[DiscountID] = [hDED].[rf_DiscountID]
INNER JOIN [hlt_DogovorPaying] as [jT_hlt_DogovorPaying] on [jT_hlt_DogovorPaying].[DogovorPayingID] = [hDED].[rf_DogovorPayingID]
INNER JOIN [hlt_DiscountReasonType] as [jT_hlt_DiscountReasonType] on [jT_hlt_DiscountReasonType].[DiscountReasonTypeID] = [hDED].[rf_DiscountReasonTypeID]
go

