CREATE VIEW [V_hlt_NotWorkDocCare] AS SELECT 
[hDED].[NotWorkDocCareID], [hDED].[x_Edition], [hDED].[x_Status], 
(CODE + ' - ' + NAME) as [v_CN], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME], 
[hDED].[Flags] as [Flags]
FROM [hlt_NotWorkDocCare] as [hDED]
go

