CREATE VIEW [V_hlt_ReestrMHSMTAP] AS SELECT 
[hDED].[ReestrMHSMTAPID], [hDED].[x_Edition], [hDED].[x_Status], 
(select top 1 [ServiceMedicalName] from oms_ServiceMedical sm
join hlt_SMTAP smtap on smtap.rf_omsServiceMedicalID = sm.ServiceMedicalID and  smtap.SMTAPID = [hDED].rf_SMTAPID) as [V_SMName], 
(((select top 1 isnull(mkab.FAMILY + ' ' + mkab.Name + ' ' + mkab.OT, '') from hlt_MKAB mkab
join hlt_TAP tap on tap.rf_MKABID = mkab.MKABID
join hlt_SMTAP smtap on tap.TAPID = smtap.rf_TAPID
where smtap.SMTAPID = [hDED].rf_SMTAPID))) as [V_FIO], 
(((SELECT '[' + ltrim(rtrim(ldoc.PCOD)) + '] '+ Upper(substring(ltrim(ldoc.FAM_V), 1, 1))+ 
CASE WHEN LEN(ldoc.FAM_V) > 0  THEN LOWER(SUBSTRING(LTRIM(RTRIM(ldoc.FAM_V)), 2, LEN(LTRIM(RTRIM(ldoc.FAM_V))) - 1))  
ELSE '' END + ' '  + Upper(substring(ltrim(ldoc.IM_V), 1, 1)) + '. ' + Upper(substring(ltrim(ldoc.OT_V), 1, 1)) 
+ '.' FROM hlt_LPUDoctor ldoc
join hlt_SMTAP smtap on smtap.rf_LPUDoctorID = ldoc.LPUDoctorID and smtap.SMTAPID = [hDED].rf_SMTAPID))) as [V_DocInfo], 
((SELECT top 1 case month_ot
when 1 then 'Январь'
when 2 then 'Февраль'
when 3 then 'Март'
when 4 then 'Апрель'
when 5 then 'Май'
when 6 then 'Июнь'
when 7 then 'Июль'
when 8 then 'Август'
when 9 then 'Сентябрь'
when 10 then 'Октябрь'
when 11 then 'Ноябрь'
when 12 then 'Декабрь'
else 'не определено'
end + ' ' + cast(year_ot as varchar) + ' г.' 
FROM hlt_ReportPeriod where ReportPeriodID = [hDED].rf_ReportPeriodID)) as [V_Year_Month], 
((SELECT top 1 DepartmentNAME from oms_Department dep
join hlt_SMTAP smtap on smtap.rf_DepartmentID = dep.DepartmentID 
and smtap.SMTAPID = [hDED].rf_SMTAPID)) as [V_DepartmenNAME], 
[jT_hlt_SMTAP].[Count] as [V_SMCount], 
[jT_hlt_SMTAP].[rf_TAPID] as [V_TAPNUM], 
[jT_hlt_SMTAP].[DATE_P] as [V_MedHelpDate], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_SMReestrID] as [rf_SMReestrID], 
[jT_oms_SMReestr].[V_SMReestr] as [SILENT_rf_SMReestrID], 
[hDED].[rf_SMTAPID] as [rf_SMTAPID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[hDED].[rf_ReestrTAPMHID] as [rf_ReestrTAPMHID], 
[jT_hlt_ReestrTAPMH].[rf_TAPID] as [SILENT_rf_ReestrTAPMHID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[hDED].[Num] as [Num], 
[hDED].[Flag] as [Flag], 
[hDED].[DateOfReturn] as [DateOfReturn], 
[hDED].[CodeErrore] as [CodeErrore], 
[hDED].[Sum_V] as [Sum_V], 
[hDED].[Sum_O] as [Sum_O], 
[hDED].[Kol_V] as [Kol_V], 
[hDED].[Kol_O] as [Kol_O], 
[hDED].[CriticalFlag] as [CriticalFlag]
FROM [hlt_ReestrMHSMTAP] as [hDED]
INNER JOIN [hlt_SMTAP] as [jT_hlt_SMTAP] on [jT_hlt_SMTAP].[SMTAPID] = [hDED].[rf_SMTAPID]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATOID]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [V_oms_SMReestr] as [jT_oms_SMReestr] on [jT_oms_SMReestr].[SMReestrID] = [hDED].[rf_SMReestrID]
INNER JOIN [hlt_ReestrTAPMH] as [jT_hlt_ReestrTAPMH] on [jT_hlt_ReestrTAPMH].[ReestrTAPMHID] = [hDED].[rf_ReestrTAPMHID]
go

