CREATE VIEW [dbo].[sl_Goscontract] AS 
SELECT 
TenderID										as idGK
,Num 											as nGK
,Date 											as dt
,Date_BP 										as dt_begin
,Date_EP 										as dt_end
,C_FINL											as TIPLG
,rf_sfoID										as Owner 
,Rem 											as comment
,rf_tendertypeID								as abr
,1				 								as TIPOPL
,1 												as isRR2
,1 												as checkprice
,1 												as Planable
,1												as DocClose
,1												as Region
,1												as Aggr
,1												as TipDoc
  FROM oms_Tender
inner join oms_sfo on sfoID=rf_sfoID
inner join oms_finl on finlID=rf_finlID
where 
TenderID<>0
go

