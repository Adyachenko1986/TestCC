CREATE VIEW [V_oms_pr_ResourceInfo] AS SELECT 
[hDED].[pr_ResourceInfoID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_pr_LPU].[V_M_NAMES] as [V_V_M_NAMES], 
[jT_oms_pr_WeekDay].[Name] as [V_NameDay], 
[jT_oms_pr_ProfType].[Name] as [V_Name], 
[hDED].[rf_kl_DDServiceID] as [rf_kl_DDServiceID], 
[jT_oms_kl_DDService].[Code] as [SILENT_rf_kl_DDServiceID], 
[hDED].[rf_pr_ProfTypeID] as [rf_pr_ProfTypeID], 
[hDED].[rf_pr_WeekDayID] as [rf_pr_WeekDayID], 
[hDED].[rf_pr_LPUID] as [rf_pr_LPUID], 
[hDED].[TypeInfo] as [TypeInfo], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags], 
[hDED].[HourBegin] as [HourBegin], 
[hDED].[HourEnd] as [HourEnd]
FROM [oms_pr_ResourceInfo] as [hDED]
INNER JOIN [V_oms_pr_LPU] as [jT_oms_pr_LPU] on [jT_oms_pr_LPU].[pr_LPUID] = [hDED].[rf_pr_LPUID]
INNER JOIN [oms_pr_WeekDay] as [jT_oms_pr_WeekDay] on [jT_oms_pr_WeekDay].[pr_WeekDayID] = [hDED].[rf_pr_WeekDayID]
INNER JOIN [oms_pr_ProfType] as [jT_oms_pr_ProfType] on [jT_oms_pr_ProfType].[pr_ProfTypeID] = [hDED].[rf_pr_ProfTypeID]
INNER JOIN [oms_kl_DDService] as [jT_oms_kl_DDService] on [jT_oms_kl_DDService].[kl_DDServiceID] = [hDED].[rf_kl_DDServiceID]
go

