CREATE VIEW [V_oms_PRVS_Profile] AS SELECT 
[hDED].[PRVS_ProfileID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_kl_DepartmentProfile].[Code] as [V_Code], 
[jT_oms_PRVD].[C_PRVD] as [V_C_PRVD], 
[jT_oms_PRVS].[C_PRVS] as [V_C_PRVS], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[jT_oms_PRVD].[NAME] as [SILENT_rf_PRVDID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[GUID] as [GUID], 
[hDED].[Name] as [Name], 
[hDED].[Rem] as [Rem], 
[hDED].[SetOn] as [SetOn], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_PRVS_Profile] as [hDED]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
go

