CREATE VIEW [V_oms_hs_plan_LPU] AS SELECT 
[hDED].[hs_plan_LPUID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_hs_plan_tfomsID] as [rf_hs_plan_tfomsID], 
[jT_oms_hs_plan_tfoms].[Value] as [SILENT_rf_hs_plan_tfomsID], 
[hDED].[Value] as [Value], 
[hDED].[Value_d] as [Value_d]
FROM [oms_hs_plan_LPU] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_hs_plan_tfoms] as [jT_oms_hs_plan_tfoms] on [jT_oms_hs_plan_tfoms].[hs_plan_tfomsID] = [hDED].[rf_hs_plan_tfomsID]
go

