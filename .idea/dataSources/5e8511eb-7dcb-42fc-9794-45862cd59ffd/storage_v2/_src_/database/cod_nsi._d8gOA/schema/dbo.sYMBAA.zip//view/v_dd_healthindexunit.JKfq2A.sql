CREATE VIEW [V_dd_HealthIndexUnit] AS SELECT 
[hDED].[HealthIndexUnitID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name_Rus] as [Name_Rus], 
[hDED].[Name_Type] as [Name_Type], 
[hDED].[Name_World] as [Name_World], 
[hDED].[Socr_Rus] as [Socr_Rus], 
[hDED].[Socr_World] as [Socr_World], 
[hDED].[Sootn] as [Sootn], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flags] as [Flags]
FROM [dd_HealthIndexUnit] as [hDED]
go

