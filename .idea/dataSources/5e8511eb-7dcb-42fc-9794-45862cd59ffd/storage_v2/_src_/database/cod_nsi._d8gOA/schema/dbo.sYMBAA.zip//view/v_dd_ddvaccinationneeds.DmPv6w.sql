CREATE VIEW [V_dd_DDVaccinationNeeds] AS SELECT 
[hDED].[DDVaccinationNeedsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[rf_DDVaccinationGUID] as [rf_DDVaccinationGUID], 
[jT_dd_DDVaccination].[Name] as [SILENT_rf_DDVaccinationGUID], 
[hDED].[Flag] as [Flag]
FROM [dd_DDVaccinationNeeds] as [hDED]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
INNER JOIN [dd_DDVaccination] as [jT_dd_DDVaccination] on [jT_dd_DDVaccination].[UGUID] = [hDED].[rf_DDVaccinationGUID]
go

