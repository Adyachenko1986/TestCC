CREATE VIEW [V_hlt_ResourceType] AS SELECT 
[hDED].[ResourceTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description]
FROM [hlt_ResourceType] as [hDED]
go

