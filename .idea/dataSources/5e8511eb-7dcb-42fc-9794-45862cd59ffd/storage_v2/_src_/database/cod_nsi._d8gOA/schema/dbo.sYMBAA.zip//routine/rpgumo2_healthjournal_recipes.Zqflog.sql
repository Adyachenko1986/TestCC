-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[RPGUMO2_HealthJournal_Recipes]
(	
	@p_ser varchar(20),
	@p_nom varchar(20),
	@dr datetime,
	@dateA datetime,
	@dateB datetime
)
RETURNS TABLE 
AS
RETURN 
(
	select 
 rec.s_rser as rser
,rec.s_rnom as rnom
,rec.s_datenap as rdate
,rec.c_katl as katl
,isnull(katl.name, '') as katlName
,rec.p_tiplg as finl
,isnull(finl.name, '') as finlName
,rec.s_fam + ' ' + rec.s_im + ' ' + rec.s_ot as docFIO
,rec.s_mkb as ds
,isnull(mkb.Name, '') as dsName
,isnull(ls.Name_Med, '') as lsName
,rec.ko_all as koall
,rec.s_sposob as sposob
,rec.s_kek as kek
,isnull(ls2.Name_Med, '') as otpLs
,isnull(k_dateotp, '1900-01-01') as otpDate
from [dbo].[SP_REC_LPU] rec
left join oms_katl katl on  rec.c_katl = katl.c_katl
left join oms_Finl finl on rec.p_tiplg = finl.C_Finl
left join oms_MKB mkb on mkb.DS = rec.s_mkb
left join oms_LS ls on ls.nomk_LS = rec.nomk_LS
left join [dbo].[SP_REC_OTP] otp on rec.s_rser = otp.s_rser and rec.s_rnom = otp.s_rnom--inner
left join oms_LS ls2 on ls2.nomk_LS = otp.nomk_LS
where ((rec.p_pser = @p_ser and rec.p_pnom = @p_nom and rec.dr = @dr) OR (rf_mkabid in (select mkabid from hlt_mkab mkab where mkab.S_POL = @p_ser and mkab.N_POL = @p_nom and mkab.Date_BD = @dr)))
and rec.k_ann = 0
and rec.s_datenap between @dateA and @dateB
)
go

