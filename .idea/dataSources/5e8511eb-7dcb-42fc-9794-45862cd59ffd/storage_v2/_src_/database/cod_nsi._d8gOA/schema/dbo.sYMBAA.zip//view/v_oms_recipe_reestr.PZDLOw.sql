CREATE VIEW [V_oms_Recipe_Reestr] AS SELECT 
[hDED].[Recipe_ReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
isNull((select count(s.PolyclinicRecipeID)as c from oms_Recipe_Reestr as r inner join oms_PolyclinicRecipe as s on s.rf_Recipe_ReestrID=r.Recipe_ReestrID and r.Recipe_ReestrID>0 where s.PolyclinicRecipeID>0),0) as [Recipe_Count], 
[hDED].[Recipe_Reestr_Num] as [Recipe_Reestr_Num], 
[hDED].[Recipe_Reestr_Begin_Date] as [Recipe_Reestr_Begin_Date], 
[hDED].[Recipe_Reestr_End_Date] as [Recipe_Reestr_End_Date], 
[hDED].[upload_date] as [upload_date]
FROM [oms_Recipe_Reestr] as [hDED]
go

