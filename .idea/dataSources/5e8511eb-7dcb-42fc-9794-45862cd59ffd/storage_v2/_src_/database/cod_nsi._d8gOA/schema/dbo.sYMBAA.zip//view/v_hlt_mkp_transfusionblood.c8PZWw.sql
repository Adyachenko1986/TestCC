CREATE VIEW [V_hlt_mkp_TransfusionBlood] AS SELECT 
[hDED].[mkp_TransfusionBloodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKABUGUID] as [rf_MKABUGUID], 
[hDED].[rf_GroupOfBloodRHID] as [rf_GroupOfBloodRHID], 
[hDED].[rf_mkpCardUGUID] as [rf_mkpCardUGUID], 
[hDED].[Description] as [Description], 
[hDED].[DateTimeTransfusion] as [DateTimeTransfusion], 
[hDED].[RhDonor] as [RhDonor], 
[hDED].[Flags] as [Flags], 
[hDED].[UGuid] as [UGuid]
FROM [hlt_mkp_TransfusionBlood] as [hDED]
go

