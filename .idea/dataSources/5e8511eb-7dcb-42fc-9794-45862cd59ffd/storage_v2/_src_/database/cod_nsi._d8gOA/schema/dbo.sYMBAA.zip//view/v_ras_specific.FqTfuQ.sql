CREATE VIEW [V_ras_Specific] AS SELECT 
[hDED].[SpecificID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[CODE] as [CODE], 
[hDED].[Name] as [Name]
FROM [ras_Specific] as [hDED]
go

