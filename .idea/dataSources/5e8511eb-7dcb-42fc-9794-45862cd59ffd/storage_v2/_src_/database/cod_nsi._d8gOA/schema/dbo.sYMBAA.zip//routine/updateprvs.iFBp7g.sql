CREATE PROCEDURE UpdatePRVS
 @codeNew varchar(30) ,
 @codeOld varchar(30)
 AS 
 BEGIN
 declare @mi varchar(10);
 declare @ma varchar(10);
 declare @SQl nvarchar(max)

 set @mi= (select prvsId from oms_PRVS where C_Prvs=@codeNew)
 set @ma= (select prvsId from oms_PRVS where C_Prvs=@codeOld)
 
 if (@mi>0 and @ma>0) begin 
 
 Set @SQL ='exec  Ref_update ''oms'' , ''rf_PRVSID'','+@ma+','+@mi
     
     EXECUTE sp_executesql @SQL
     
     Set @SQL ='exec  Ref_update ''HEALTH'' , ''rf_PRVSID'','+@ma+','+@mi
     
     EXECUTE sp_executesql @SQL

     Set @SQL ='exec  Ref_update ''STT'' , ''rf_PRVSID'','+@ma+','+@mi
     
     EXECUTE sp_executesql @SQL
     
     print @SQl
     Set @SQL ='delete from oms_PRVS where PRVSID ='+@ma
     EXECUTE sp_executesql @SQL
 end 
END
go

