CREATE VIEW [V_ras_Provider] AS SELECT 
[hDED].[ProviderID], [hDED].[HostProviderID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_Organisation].[Name] as [V_Organisation], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[Name] as [Name]
FROM [ras_Provider] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationIDHost]
go

