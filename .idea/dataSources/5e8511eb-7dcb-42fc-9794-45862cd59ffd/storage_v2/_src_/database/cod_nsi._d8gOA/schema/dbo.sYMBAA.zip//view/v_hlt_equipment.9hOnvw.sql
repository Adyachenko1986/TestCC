CREATE VIEW [V_hlt_Equipment] AS SELECT 
[hDED].[EquipmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_HealingRoomID] as [rf_HealingRoomID], 
[jT_hlt_HealingRoom].[Num] as [SILENT_rf_HealingRoomID], 
[hDED].[rf_EquipmentTypeID] as [rf_EquipmentTypeID], 
[jT_hlt_EquipmentType].[Name] as [SILENT_rf_EquipmentTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Producer] as [Producer], 
[hDED].[Document] as [Document], 
[hDED].[DateIn] as [DateIn], 
[hDED].[DateOut] as [DateOut], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[InventoryNumber] as [InventoryNumber], 
[hDED].[IsMobile] as [IsMobile], 
[hDED].[DateProduction] as [DateProduction], 
[hDED].[DateDecommission] as [DateDecommission], 
[hDED].[IsDigital] as [IsDigital]
FROM [hlt_Equipment] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [hlt_HealingRoom] as [jT_hlt_HealingRoom] on [jT_hlt_HealingRoom].[HealingRoomID] = [hDED].[rf_HealingRoomID]
INNER JOIN [hlt_EquipmentType] as [jT_hlt_EquipmentType] on [jT_hlt_EquipmentType].[EquipmentTypeID] = [hDED].[rf_EquipmentTypeID]
go

