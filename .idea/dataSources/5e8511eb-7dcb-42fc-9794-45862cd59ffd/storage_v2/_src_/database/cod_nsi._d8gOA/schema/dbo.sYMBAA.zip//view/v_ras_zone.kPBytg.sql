CREATE VIEW [V_ras_Zone] AS SELECT 
[hDED].[ZoneID], [hDED].[HostZoneID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note], 
[hDED].[Barcode] as [Barcode]
FROM [ras_Zone] as [hDED]
go

