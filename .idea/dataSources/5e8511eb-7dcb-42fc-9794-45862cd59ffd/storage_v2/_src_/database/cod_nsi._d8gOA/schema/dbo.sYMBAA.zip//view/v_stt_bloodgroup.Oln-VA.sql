CREATE VIEW [V_stt_BloodGroup] AS SELECT 
[hDED].[BloodGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[ABSysNum] as [ABSysNum], 
[hDED].[NumRim] as [NumRim], 
[hDED].[Num] as [Num], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_BloodGroup] as [hDED]
go

