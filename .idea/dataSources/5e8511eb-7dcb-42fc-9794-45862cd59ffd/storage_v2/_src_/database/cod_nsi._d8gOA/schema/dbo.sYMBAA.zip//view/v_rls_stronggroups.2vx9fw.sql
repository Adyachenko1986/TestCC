CREATE VIEW [V_rls_StrongGroups] AS SELECT 
[hDED].[StrongGroupsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [rls_StrongGroups] as [hDED]
go

