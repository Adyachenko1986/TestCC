CREATE VIEW [V_oms_Reestr_Sprav_State] AS SELECT 
[hDED].[Reestr_Sprav_StateID], [hDED].[x_Edition], [hDED].[x_Status], 
(select case when Type=1 then 'НСИ' when Type=2 then 'Протокол' when Type=3 then 'Критерий' when Type=4 then 'Функция расчета' else '' end) as [V_Type], 
[hDED].[rf_reestr_SpravID] as [rf_reestr_SpravID], 
[jT_oms_reestr_Sprav].[Num] as [SILENT_rf_reestr_SpravID], 
[hDED].[DateEdit] as [DateEdit], 
[hDED].[Rem] as [Rem], 
[hDED].[Type] as [Type], 
[hDED].[Flags] as [Flags]
FROM [oms_Reestr_Sprav_State] as [hDED]
INNER JOIN [oms_reestr_Sprav] as [jT_oms_reestr_Sprav] on [jT_oms_reestr_Sprav].[reestr_SpravID] = [hDED].[rf_reestr_SpravID]
go

