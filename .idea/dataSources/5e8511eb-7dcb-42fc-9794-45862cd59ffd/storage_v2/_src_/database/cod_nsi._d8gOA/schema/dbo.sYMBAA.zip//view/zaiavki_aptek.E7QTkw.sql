CREATE VIEW [Заявки_аптек] AS select 
dem.OGRN_client as [ОГРН],
org.[CODE] as [Код Аптеки],
org.[name] as [Аптека],
dem.[date]as [Дата заявки],
dtype.[Name] as [Тип заявки],
nom.[name] as [Название ЛС],
pos.c_lsfo as [Код ЛС фоарморганизации],
pos.c_pfs as [Код позиции печня],
pos.[count]as [Количество упаковок ЛС]

from 
	ras_demand as dem,
	ras_PositionDemand as pos,
	ras_organisation as org, 	
	ras_Nomenclature as nom,
	ras_TypeDemand as Dtype
where 
(dem.rf_OrganisationClientID=org.OrganisationID)and
(pos.rf_NomenclatureID=nom.NomenclatureID)and
(dem.rf_typedemandID=dtype.typedemandid)and
(pos.rf_DemandID=dem.demandID)and
(dem.demandId>0)and(pos.PositiondemandID>0)and
(dem.rf_OrganisationProviderID<>0)and
(dem.rf_OrganisationClientID<>0)and(pos.[count]>0)
go

