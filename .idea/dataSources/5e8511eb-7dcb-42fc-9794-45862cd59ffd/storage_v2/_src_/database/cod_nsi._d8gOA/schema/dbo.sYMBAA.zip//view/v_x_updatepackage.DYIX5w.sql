CREATE VIEW [dbo].[V_x_UpdatePackage] AS SELECT 
[hDED].[UpdatePackageID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[FileRelativePath] as [FileRelativePath], 
[hDED].[Data] as [Data], 
[hDED].[Hash] as [Hash], 
[hDED].[IsDeleted] as [IsDeleted], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[Flags] as [Flags]
FROM [x_UpdatePackage] as [hDED]
go

