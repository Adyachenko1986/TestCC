
CREATE VIEW [dbo].[V_x_User] AS SELECT 
[hDED].[UserID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[WindowsName] as [WindowsName], 
[hDED].[GeneralLogin] as [GeneralLogin], 
[hDED].[GeneralPassword] as [GeneralPassword], 
[hDED].[AuthMode] as [AuthMode], 
[hDED].[FIO] as [FIO], 
[hDED].[GUID] as [GUID], 
[hDED].[Email] as [Email]
FROM [x_User] as [hDED]
go

