

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[rtInfomatVisitNotification] 
   ON [dbo].[hlt_DoctorVisitTable] 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here

	INSERT INTO [hlt_MessageQueue]
           ([x_Edition]
           ,[x_Status]
           ,[Type]
           ,[Message]
           ,[Date]           
           ,[GUID]           
           ,[rf_MkabGUID]
           ,[Subject]
           ,[Address])
     SELECT
            1 as [x_Edition]
           ,1 as [x_Status]
           ,'SMS' as [Type]
           ,'' as [Message]
           ,Getdate() as [Date]           
           ,newid() as [GUID]           
           ,mkab.UGUID as [rf_MkabGUID]
           ,'Врач ' +
			Upper(substring(doc.Fam_V, 1,1)) + Lower(substring(doc.Fam_V, 2,50)) + ' ' + Upper(substring(doc.IM_V, 1,1)) + '. ' + Upper(substring(doc.OT_V, 1,1)) + '. ' +
			' ждет вас ' + 
			convert(varchar(5), dtt.Date, 104)+ 
			' в ' +
			convert(varchar(5), Begin_Time, 114) + 
			' в кабинете №' + 
			hr.Num +
			'.' as [Subject]
           ,mkab.contactMPhone as [Address]
	from inserted i
		inner join hlt_mkab mkab
			on mkab.mkabid= i.rf_MKABID
		inner join hlt_DoctorTimeTable dtt
			on dtt.DoctorTimeTableID = i.rf_DoctorTimeTableID
		inner join hlt_DocPRVD dprvd
			on dtt.rf_DocPRVDID = dprvd.DocPRVDID
		inner join hlt_LPUDoctor doc
			on doc.LPUDoctorID = dprvd.rf_LPUDoctorID
		inner join hlt_HealingRoom hr
			on hr.HealingRoomID = dprvd.rf_HealingRoomID
	where i.fromInternet = 1
		and mkab.ConfirmAgree = 1

END


go

