CREATE VIEW [V_dd_DDDifficultSituation] AS SELECT 
[hDED].[DDDifficultSituationID], [hDED].[x_Edition], [hDED].[x_Status], 
((Select Name from dd_DDDifficultSituationType
where UGUID =rf_DDDifficultSituationTypeGUID)) as [V_DDDifficultSituationType], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[hDED].[rf_DDDifficultSituationTypeGUID] as [rf_DDDifficultSituationTypeGUID], 
[hDED].[Flag] as [Flag]
FROM [dd_DDDifficultSituation] as [hDED]
go

