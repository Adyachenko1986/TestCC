CREATE VIEW [V_oms_kl_ActionTeeth] AS SELECT 
[hDED].[kl_ActionTeethID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Description] as [Description], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags]
FROM [oms_kl_ActionTeeth] as [hDED]
go

