CREATE VIEW [V_dd_DDStationarInstitutionType] AS SELECT 
[hDED].[DDStationarInstitutionTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag]
FROM [dd_DDStationarInstitutionType] as [hDED]
go

