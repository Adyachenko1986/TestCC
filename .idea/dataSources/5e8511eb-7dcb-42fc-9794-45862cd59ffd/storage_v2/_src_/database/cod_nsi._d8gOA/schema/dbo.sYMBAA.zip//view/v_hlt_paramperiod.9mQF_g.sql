CREATE VIEW [V_hlt_ParamPeriod] AS SELECT 
[hDED].[ParamPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[rf_ParamTypePeriodID] as [rf_ParamTypePeriodID], 
[jT_hlt_ParamTypePeriod].[Code] as [SILENT_rf_ParamTypePeriodID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_ParamPeriod] as [hDED]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
INNER JOIN [hlt_ParamTypePeriod] as [jT_hlt_ParamTypePeriod] on [jT_hlt_ParamTypePeriod].[ParamTypePeriodID] = [hDED].[rf_ParamTypePeriodID]
go

