CREATE VIEW [V_oms_OKATO] AS SELECT 
[hDED].[OKATOID], [hDED].[x_Edition], [hDED].[x_Status], 
C_OKATO as [EDV_C_OKATO], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[C_OKATO] as [C_OKATO], 
[hDED].[O_NAME] as [O_NAME], 
[hDED].[C_PFR] as [C_PFR], 
[hDED].[FOK_NAME] as [FOK_NAME], 
[hDED].[PFRcode] as [PFRcode], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_OKATO] as [hDED]
go

