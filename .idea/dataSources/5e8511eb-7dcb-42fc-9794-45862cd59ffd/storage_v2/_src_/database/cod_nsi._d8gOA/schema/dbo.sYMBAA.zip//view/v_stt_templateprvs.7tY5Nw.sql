CREATE VIEW [V_stt_TemplatePRVS] AS SELECT 
[hDED].[TemplatePRVSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_TemplateTypeID] as [rf_TemplateTypeID], 
[jT_stt_TemplateType].[Name] as [SILENT_rf_TemplateTypeID]
FROM [stt_TemplatePRVS] as [hDED]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [stt_TemplateType] as [jT_stt_TemplateType] on [jT_stt_TemplateType].[TemplateTypeID] = [hDED].[rf_TemplateTypeID]
go

