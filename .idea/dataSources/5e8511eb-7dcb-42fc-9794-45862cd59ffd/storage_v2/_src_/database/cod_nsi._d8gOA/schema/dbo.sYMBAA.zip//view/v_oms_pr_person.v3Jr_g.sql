CREATE VIEW [V_oms_pr_Person] AS SELECT 
[hDED].[pr_PersonID], [hDED].[x_Edition], [hDED].[x_Status], 
((((Fam+' '+Im+' '+Ot+', '+convert(varchar,DR,104)+' г.')))) as [V_Person], 
(((ltrim(rtrim(S_POL+' '+N_POL))))) as [V_POL], 
[jT_oms_kl_TypeU].[Name] as [V_NameUch], 
[jT_oms_LPU].[M_NAMES] as [V_M_NAMES], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[hDED].[rf_kl_TypeUID] as [rf_kl_TypeUID], 
[hDED].[Fam] as [Fam], 
[hDED].[Im] as [Im], 
[hDED].[Ot] as [Ot], 
[hDED].[DR] as [DR], 
[hDED].[OS_SLUCH] as [OS_SLUCH], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[DOMC_DATE] as [DOMC_DATE], 
[hDED].[ENP] as [ENP], 
[hDED].[DatePR] as [DatePR], 
[hDED].[SP_PRIK] as [SP_PRIK], 
[hDED].[T_PRIK] as [T_PRIK], 
[hDED].[NUM_UCH] as [NUM_UCH], 
[hDED].[SNILS_VR] as [SNILS_VR], 
[hDED].[PHONE1] as [PHONE1], 
[hDED].[PHONE2] as [PHONE2], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Rem] as [Rem], 
[hDED].[Address] as [Address], 
[hDED].[SS] as [SS], 
[hDED].[DeathDate] as [DeathDate], 
[hDED].[FIO_UCH] as [FIO_UCH]
FROM [oms_pr_Person] as [hDED]
INNER JOIN [oms_kl_TypeU] as [jT_oms_kl_TypeU] on [jT_oms_kl_TypeU].[kl_TypeUID] = [hDED].[rf_kl_TypeUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

