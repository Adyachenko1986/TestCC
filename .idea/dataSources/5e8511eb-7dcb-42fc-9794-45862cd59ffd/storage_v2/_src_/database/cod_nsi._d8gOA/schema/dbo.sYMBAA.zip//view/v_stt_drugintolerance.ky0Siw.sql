CREATE VIEW [V_stt_DrugIntolerance] AS SELECT 
[hDED].[DrugIntoleranceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[SideEffect] as [SideEffect], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags], 
[hDED].[DrugName] as [DrugName]
FROM [stt_DrugIntolerance] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
go

