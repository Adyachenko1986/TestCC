CREATE VIEW [V_stt_Template] AS SELECT 
[hDED].[TemplateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateTypeID] as [rf_TemplateTypeID], 
[jT_stt_TemplateType].[Name] as [SILENT_rf_TemplateTypeID], 
[hDED].[rf_TemplateModeID] as [rf_TemplateModeID], 
[jT_stt_TemplateMode].[ModeName] as [SILENT_rf_TemplateModeID], 
[hDED].[HTMLTemplate] as [HTMLTemplate]
FROM [stt_Template] as [hDED]
INNER JOIN [stt_TemplateType] as [jT_stt_TemplateType] on [jT_stt_TemplateType].[TemplateTypeID] = [hDED].[rf_TemplateTypeID]
INNER JOIN [stt_TemplateMode] as [jT_stt_TemplateMode] on [jT_stt_TemplateMode].[TemplateModeID] = [hDED].[rf_TemplateModeID]
go

