CREATE VIEW [dbo].[sl_flow] AS 
SELECT 
ExtractedLSfromReestrID							as idFlow
,rf_DPCPharmacyRecipeID							as idRecipe
,d_type											as d_type
,substring(SERIES,0,15)								as series
,PARTIA											as part
,nomk_ls										as nomk_ls
,oms_Tender.TenderID							as lot
,Count											as ko_all
,round(r.Price*Count,2)							as sl_all
,sfoID											as owner
,''												as idschet
,''												as idreestr
,''												as InReestr
,''												as estate
,Bill_Num										as dNumber
,''												as actual
,r.Price										as price100
,''												as sTypeTmp
  FROM dbo.ras_ExtractedLSfromReestr r
inner join dbo.oms_DPCPharmacyRecipe on DPCPharmacyRecipeID=rf_DPCPharmacyRecipeID
inner join dbo.oms_ls on lsID=rf_lsID
inner join dbo.oms_sfo on sfoID=rf_sfoID
inner join dbo.oms_tender oms_Tender on tenderID=r.rf_tenderID
where statusedition=0 and DPCPharmacyRecipeid<>0
go

