CREATE VIEW [V_hlt_NotWorkDocDisableState] AS SELECT 
[hDED].[NotWorkDocDisableStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_NotWorkDocDisableState] as [hDED]
go

