CREATE VIEW [V_hlt_mkp_DeathMother] AS SELECT 
[hDED].[mkp_DeathMotherID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[UGUID] as [UGUID], 
[hDED].[ReasonDeath] as [ReasonDeath], 
[hDED].[DateTimeDeath] as [DateTimeDeath], 
[hDED].[Conclusion] as [Conclusion]
FROM [hlt_mkp_DeathMother] as [hDED]
go

