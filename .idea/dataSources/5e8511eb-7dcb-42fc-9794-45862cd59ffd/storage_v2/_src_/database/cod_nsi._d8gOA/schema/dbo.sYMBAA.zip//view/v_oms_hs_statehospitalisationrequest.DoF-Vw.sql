CREATE VIEW [V_oms_hs_StateHospitalisationRequest] AS SELECT 
[hDED].[hs_StateHospitalisationRequestID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [oms_hs_StateHospitalisationRequest] as [hDED]
go

