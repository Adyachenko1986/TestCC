CREATE view [V_x_Role] as select RoleID, x_Edition, x_Status,
Name, GUID, Type from x_Role
go

