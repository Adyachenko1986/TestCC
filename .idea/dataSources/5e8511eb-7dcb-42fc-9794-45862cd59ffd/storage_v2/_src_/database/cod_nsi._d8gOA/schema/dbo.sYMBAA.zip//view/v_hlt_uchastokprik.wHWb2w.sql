CREATE VIEW [V_hlt_UchastokPRIK] AS SELECT 
[hDED].[UchastokPRIKID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_SMO].[Q_NAME] as [V_SMO], 
[jT_hlt_Uchastok].[UchastoCaption] as [V_Uchastok], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Summ_Stim] as [Summ_Stim], 
[hDED].[Summ_APP] as [Summ_APP], 
[hDED].[Rem] as [Rem], 
[hDED].[k_priv] as [k_priv], 
[hDED].[Flags] as [Flags], 
[hDED].[Date_Edit] as [Date_Edit], 
[hDED].[Count_Prik] as [Count_Prik]
FROM [hlt_UchastokPRIK] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [hlt_Uchastok] as [jT_hlt_Uchastok] on [jT_hlt_Uchastok].[UchastokID] = [hDED].[rf_UchastokID]
go

