CREATE VIEW [V_dd_ExamSM] AS SELECT 
[hDED].[ExamSMID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_dd_DDExam].[V_DDServiceName] as [V_V_DDServiceName], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [V_ServiceMedicalName], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[hDED].[rf_ServiceMedicalGUIDSM] as [rf_ServiceMedicalGUIDSM], 
[hDED].[rf_SMTAPGuid] as [rf_SMTAPGuid], 
[hDED].[rf_DDExamGUID] as [rf_DDExamGUID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flags] as [Flags]
FROM [dd_ExamSM] as [hDED]
INNER JOIN [V_dd_DDExam] as [jT_dd_DDExam] on [jT_dd_DDExam].[DDExamGUID] = [hDED].[rf_DDExamGUID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[GUIDSM] = [hDED].[rf_ServiceMedicalGUIDSM]
go

