CREATE VIEW [V_rls_ClsIic] AS SELECT 
[hDED].[ClsIicID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsIicUID] as [rf_ClsIicUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[INFO] as [INFO]
FROM [rls_ClsIic] as [hDED]
go

