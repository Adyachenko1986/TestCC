CREATE VIEW [V_hlt_OtherSMO] AS SELECT 
[hDED].[OtherSMOID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_Organisation].[Bank] as [V_Bank], 
[jT_oms_Organisation].[R_Account] as [V_R_Account], 
[jT_oms_Organisation].[BIK_Bank] as [V_BIK_Bank], 
[jT_oms_Organisation].[C_Account] as [V_C_Account], 
[jT_oms_Organisation].[INN] as [V_INN], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[Q_OKPO] as [Q_OKPO], 
[hDED].[Q_NAME] as [Q_NAME], 
[hDED].[ADDRESS] as [ADDRESS], 
[hDED].[TF_COD] as [TF_COD], 
[hDED].[OKATO] as [OKATO], 
[hDED].[Q_OGRN] as [Q_OGRN], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[CODE] as [CODE]
FROM [hlt_OtherSMO] as [hDED]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation] on [jT_oms_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID]
go

