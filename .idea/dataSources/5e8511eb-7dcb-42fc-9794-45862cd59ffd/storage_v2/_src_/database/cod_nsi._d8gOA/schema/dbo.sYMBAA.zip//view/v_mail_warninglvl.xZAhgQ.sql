CREATE VIEW [V_mail_WarningLvl] AS SELECT 
[hDED].[WarningLvlID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName]
FROM [mail_WarningLvl] as [hDED]
go

