CREATE VIEW [V_rls_DrugStorCond] AS SELECT 
[hDED].[DrugStorCondID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Text] as [Text], 
[hDED].[Code] as [Code]
FROM [rls_DrugStorCond] as [hDED]
go

