
CREATE TRIGGER [dbo].[tap_ReturnsTypeID] 
   ON [dbo].[hlt_TAP]
   AFTER INSERT, UPDATE
AS 
BEGIN
    SET NOCOUNT ON;

    update hlt_ReestrTAPMH
    set rf_ReestrMHReturnsTypeID = 0
    from hlt_ReestrTAPMH 
    join inserted i on i.TAPID = hlt_ReestrTAPMH.rf_TAPID
END
go

