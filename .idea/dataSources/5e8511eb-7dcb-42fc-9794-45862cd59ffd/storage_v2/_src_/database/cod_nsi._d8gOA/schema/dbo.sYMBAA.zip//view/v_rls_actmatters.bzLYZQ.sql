CREATE VIEW [V_rls_ActMatters] AS SELECT 
[hDED].[ActMattersID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_NarcoGroupsUID] as [rf_NarcoGroupsUID], 
[hDED].[rf_StrongGroupsUID] as [rf_StrongGroupsUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[RusName] as [RusName], 
[hDED].[LatName] as [LatName], 
[hDED].[ChemicalName] as [ChemicalName], 
[hDED].[Characters] as [Characters], 
[hDED].[PharmaCology] as [PharmaCology], 
[hDED].[Indications] as [Indications], 
[hDED].[Usage] as [Usage], 
[hDED].[Contraindications] as [Contraindications], 
[hDED].[Uselimitations] as [Uselimitations], 
[hDED].[Sideactions] as [Sideactions], 
[hDED].[Interactions] as [Interactions], 
[hDED].[UseMmethodAndDoses] as [UseMmethodAndDoses], 
[hDED].[OverDose] as [OverDose], 
[hDED].[Pregnancyuse] as [Pregnancyuse], 
[hDED].[Precautions] as [Precautions], 
[hDED].[SpecialGuidelines] as [SpecialGuidelines], 
[hDED].[UID] as [UID], 
[hDED].[Literature] as [Literature], 
[hDED].[Code] as [Code], 
[hDED].[LatName_Parent] as [LatName_Parent]
FROM [rls_ActMatters] as [hDED]
go

