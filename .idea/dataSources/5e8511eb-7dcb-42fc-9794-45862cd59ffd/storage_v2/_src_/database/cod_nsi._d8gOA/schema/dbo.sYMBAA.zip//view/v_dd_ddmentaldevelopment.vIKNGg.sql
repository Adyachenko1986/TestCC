CREATE VIEW [V_dd_DDMentalDevelopment] AS SELECT 
[hDED].[DDMentalDevelopmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[CognitionFunction] as [CognitionFunction], 
[hDED].[MotorFunction] as [MotorFunction], 
[hDED].[EmotionalFunction] as [EmotionalFunction], 
[hDED].[SpeechFunction] as [SpeechFunction], 
[hDED].[PsyhoMotorSphere] as [PsyhoMotorSphere], 
[hDED].[Intellect] as [Intellect], 
[hDED].[EmotionalVegetativeSphere] as [EmotionalVegetativeSphere], 
[hDED].[Flag] as [Flag], 
[hDED].[SocialFunction] as [SocialFunction]
FROM [dd_DDMentalDevelopment] as [hDED]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
go

