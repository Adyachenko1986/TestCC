CREATE VIEW [V_hlt_mkp_Card] AS SELECT 
[hDED].[mkp_CardID], [hDED].[x_Edition], [hDED].[x_Status], 
(((CASE [hDED].RiskFrolova
         WHEN 0 THEN ''
         WHEN 1 THEN 'Без риска'
         WHEN 2 THEN 'Легкая степень'
         WHEN 3 THEN 'Средняя степень'
         WHEN 4 THEN 'Высокая степень'
         ELSE ''
      END))) as [V_RiskFrolova], 
(dbo.GetGestatioAge([hDED].rf_PergGUID, [hDED].DateOpen, [hDED].FirstGestationalAge, [hDED].gestBirth) ) as [V_CountWeeks], 
((case  [hDED].StatusRisk WHEN 0 THEN 'Проверка не проводилась' WHEN 1 THEN 'Без группы риска' WHEN 2 THEN 'Первая группа (низкая степерь риска)' WHEN 3 THEN 'Вторая группа (средняя степень риска)' WHEN 4 THEN 'Третья А группа (высокая степень риска)' WHEN 5 THEN 'Третья Б группа (высокая степень риска)' ELSE '' END)) as [V_StatusRisk], 
((CASE [hDED].RiskSavelyeva WHEN 0 THEN 'Проверка гестоза не проводилась'  WHEN 1 THEN 'Без риска гестоза' WHEN 2 THEN 'Легкая степень гестоза' WHEN 3 THEN 'Средняя степень гестоза' WHEN 4 THEN 'Тяжелая степень гестоза'  ELSE '' END)) as [V_RiskSavelyeva], 
((CASE [hDED].RiskVittlengera WHEN 0 THEN 'Определение нефропатии не проводилось' WHEN 1 THEN 'Без нефропатии' WHEN 2 THEN 'Легкая степень нефропатии' WHEN 3 THEN 'Средняя степень нефропатии' WHEN 4 THEN 'Тяжелая степень нефропатии' ELSE '' END)) as [V_RiskVittlengera], 
((CASE [hDED].RiskRadzinskogo WHEN 0 THEN 'Определение степени пренатального риска не проводилось' WHEN 1 THEN 'Без пренатального риска' WHEN 2 THEN 'Низкая степень пренатального риска' WHEN 3 THEN 'Средняя степень пренатального риска' WHEN 4 THEN 'Высокая степень пренатального риска' ELSE '' END)) as [V_RiskRadzinskogo], 
[jT_hlt_MKAB].[V_FIO] as [V_V_FIO], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_PlanLPUID] as [rf_PlanLPUID], 
[jT_oms_LPU1].[M_NAMES] as [SILENT_rf_PlanLPUID], 
[hDED].[rf_EmergLPUID] as [rf_EmergLPUID], 
[jT_oms_LPU2].[M_NAMES] as [SILENT_rf_EmergLPUID], 
[hDED].[rf_BornLPUID] as [rf_BornLPUID], 
[jT_oms_LPU3].[M_NAMES] as [SILENT_rf_BornLPUID], 
[hDED].[rf_HospitalLPUID] as [rf_HospitalLPUID], 
[jT_oms_LPU4].[M_NAMES] as [SILENT_rf_HospitalLPUID], 
[hDED].[rf_birthOutcomesID] as [rf_birthOutcomesID], 
[jT_oms_MKB].[DS] as [SILENT_rf_birthOutcomesID], 
[hDED].[rf_DepartamentGUID] as [rf_DepartamentGUID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartamentGUID], 
[hDED].[rf_MKABGUID] as [rf_MKABGUID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABGUID], 
[hDED].[rf_GroupOfBloodRHID] as [rf_GroupOfBloodRHID], 
[jT_hlt_GroupOfBloodRH].[NAME] as [SILENT_rf_GroupOfBloodRHID], 
[hDED].[rf_F_GroupOfBloodRHID] as [rf_F_GroupOfBloodRHID], 
[jT_hlt_GroupOfBloodRH1].[NAME] as [SILENT_rf_F_GroupOfBloodRHID], 
[hDED].[rf_LPUDoctorGUID] as [rf_LPUDoctorGUID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorGUID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_NationalGUID] as [rf_NationalGUID], 
[jT_hlt_National].[V_Descr] as [SILENT_rf_NationalGUID], 
[hDED].[rf_F_NationalGUID] as [rf_F_NationalGUID], 
[jT_hlt_National1].[V_Descr] as [SILENT_rf_F_NationalGUID], 
[hDED].[rf_PergGUID] as [rf_PergGUID], 
[jT_hlt_mkp_Perg].[Name] as [SILENT_rf_PergGUID], 
[hDED].[rf_mkp_DeathMother] as [rf_mkp_DeathMother], 
[jT_hlt_mkp_DeathMother].[ReasonDeath] as [SILENT_rf_mkp_DeathMother], 
[hDED].[rf_mkp_OutcomeGUID] as [rf_mkp_OutcomeGUID], 
[jT_hlt_mkp_Outcome].[V_Descr] as [SILENT_rf_mkp_OutcomeGUID], 
[hDED].[rf_mkpAbortUguid] as [rf_mkpAbortUguid], 
[hDED].[rf_mkp_CloseReasonID] as [rf_mkp_CloseReasonID], 
[jT_hlt_mkp_CloseReason].[Name] as [SILENT_rf_mkp_CloseReasonID], 
[hDED].[NUM] as [NUM], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Maiden_FAM] as [Maiden_FAM], 
[hDED].[F_FAM] as [F_FAM], 
[hDED].[F_NAME] as [F_NAME], 
[hDED].[F_OT] as [F_OT], 
[hDED].[F_Work] as [F_Work], 
[hDED].[F_Post] as [F_Post], 
[hDED].[F_Profession] as [F_Profession], 
[hDED].[F_DR] as [F_DR], 
[hDED].[Sert_S] as [Sert_S], 
[hDED].[Sert_N] as [Sert_N], 
[hDED].[Sert_Date] as [Sert_Date], 
[hDED].[Sert_Term] as [Sert_Term], 
[hDED].[NumMar] as [NumMar], 
[hDED].[NumPreg] as [NumPreg], 
[hDED].[NumBirth] as [NumBirth], 
[hDED].[DateOpen] as [DateOpen], 
[hDED].[DateClose] as [DateClose], 
[hDED].[DateFirst] as [DateFirst], 
[hDED].[DateMenstr] as [DateMenstr], 
[hDED].[DateOvul] as [DateOvul], 
[hDED].[DateStir] as [DateStir], 
[hDED].[Allergy] as [Allergy], 
[hDED].[Intolerance] as [Intolerance], 
[hDED].[DateHospital] as [DateHospital], 
[hDED].[DateExtract] as [DateExtract], 
[hDED].[DateBirth] as [DateBirth], 
[hDED].[GestBirth] as [GestBirth], 
[hDED].[Flags] as [Flags], 
[hDED].[rf_CreateUserGUID] as [rf_CreateUserGUID], 
[hDED].[rf_EditUserGUID] as [rf_EditUserGUID], 
[hDED].[CreateUserName] as [CreateUserName], 
[hDED].[EditUserName] as [EditUserName], 
[hDED].[IsClosed] as [IsClosed], 
[hDED].[XmlData] as [XmlData], 
[hDED].[Treatment] as [Treatment], 
[hDED].[RiskFrolova] as [RiskFrolova], 
[hDED].[National] as [National], 
[hDED].[NationalF] as [NationalF], 
[hDED].[FirstGestationalAge] as [FirstGestationalAge], 
[hDED].[PregCondDisch] as [PregCondDisch], 
[hDED].[DateFirstInspection] as [DateFirstInspection], 
[hDED].[StatusRisk] as [StatusRisk], 
[hDED].[RiskVittlengera] as [RiskVittlengera], 
[hDED].[RiskSavelyeva] as [RiskSavelyeva], 
[hDED].[RiskRadzinskogo] as [RiskRadzinskogo], 
[hDED].[HospitalLPU] as [HospitalLPU]
FROM [hlt_mkp_Card] as [hDED]
INNER JOIN [V_hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[UGUID] = [hDED].[rf_MKABGUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU1] on [jT_oms_LPU1].[LPUID] = [hDED].[rf_PlanLPUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU2] on [jT_oms_LPU2].[LPUID] = [hDED].[rf_EmergLPUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU3] on [jT_oms_LPU3].[LPUID] = [hDED].[rf_BornLPUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU4] on [jT_oms_LPU4].[LPUID] = [hDED].[rf_HospitalLPUID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_birthOutcomesID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[GUIDDepartment] = [hDED].[rf_DepartamentGUID]
INNER JOIN [hlt_GroupOfBloodRH] as [jT_hlt_GroupOfBloodRH] on [jT_hlt_GroupOfBloodRH].[GroupOfBloodRHID] = [hDED].[rf_GroupOfBloodRHID]
INNER JOIN [hlt_GroupOfBloodRH] as [jT_hlt_GroupOfBloodRH1] on [jT_hlt_GroupOfBloodRH1].[GroupOfBloodRHID] = [hDED].[rf_F_GroupOfBloodRHID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[UGUID] = [hDED].[rf_LPUDoctorGUID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [V_hlt_National] as [jT_hlt_National] on [jT_hlt_National].[UGUID] = [hDED].[rf_NationalGUID]
INNER JOIN [V_hlt_National] as [jT_hlt_National1] on [jT_hlt_National1].[UGUID] = [hDED].[rf_F_NationalGUID]
INNER JOIN [hlt_mkp_Perg] as [jT_hlt_mkp_Perg] on [jT_hlt_mkp_Perg].[UGUID] = [hDED].[rf_PergGUID]
INNER JOIN [hlt_mkp_DeathMother] as [jT_hlt_mkp_DeathMother] on [jT_hlt_mkp_DeathMother].[UGUID] = [hDED].[rf_mkp_DeathMother]
INNER JOIN [V_hlt_mkp_Outcome] as [jT_hlt_mkp_Outcome] on [jT_hlt_mkp_Outcome].[UGUID] = [hDED].[rf_mkp_OutcomeGUID]
INNER JOIN [hlt_mkp_CloseReason] as [jT_hlt_mkp_CloseReason] on [jT_hlt_mkp_CloseReason].[mkp_CloseReasonID] = [hDED].[rf_mkp_CloseReasonID]
go

