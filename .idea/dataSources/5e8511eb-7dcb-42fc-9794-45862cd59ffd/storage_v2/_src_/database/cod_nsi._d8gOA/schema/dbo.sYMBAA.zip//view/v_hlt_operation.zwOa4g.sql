CREATE VIEW [V_hlt_Operation] AS SELECT 
[hDED].[OperationID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfo], 
[jT_oms_kl_OperationType].[Name] as [V_OperationTypeName], 
[hDED].[rf_kl_OperationTypeID] as [rf_kl_OperationTypeID], 
[jT_oms_kl_OperationType].[Name] as [SILENT_rf_kl_OperationTypeID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_kl_AnasthesiaTypeID] as [rf_kl_AnasthesiaTypeID], 
[jT_oms_kl_AnasthesiaType].[Code] as [SILENT_rf_kl_AnasthesiaTypeID], 
[hDED].[rf_kl_OperationID] as [rf_kl_OperationID], 
[jT_oms_kl_Operation].[Name] as [SILENT_rf_kl_OperationID], 
[hDED].[DateTimeBegin] as [DateTimeBegin], 
[hDED].[DateTimeEnd] as [DateTimeEnd], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[rf_CreateUserID] as [rf_CreateUserID], 
[hDED].[CreateUserName] as [CreateUserName], 
[hDED].[rf_EditUserID] as [rf_EditUserID], 
[hDED].[EditUserName] as [EditUserName]
FROM [hlt_Operation] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [oms_kl_OperationType] as [jT_oms_kl_OperationType] on [jT_oms_kl_OperationType].[kl_OperationTypeID] = [hDED].[rf_kl_OperationTypeID]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [oms_kl_AnasthesiaType] as [jT_oms_kl_AnasthesiaType] on [jT_oms_kl_AnasthesiaType].[kl_AnasthesiaTypeID] = [hDED].[rf_kl_AnasthesiaTypeID]
INNER JOIN [oms_kl_Operation] as [jT_oms_kl_Operation] on [jT_oms_kl_Operation].[kl_OperationID] = [hDED].[rf_kl_OperationID]
go

