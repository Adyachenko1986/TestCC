CREATE VIEW [V_ras_StateBillRevaluation] AS SELECT 
[hDED].[StateBillRevaluationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[Name] as [Name]
FROM [ras_StateBillRevaluation] as [hDED]
go

