CREATE VIEW [V_oms_kl_OS_Sluch] AS SELECT 
[hDED].[kl_OS_SluchID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Rem] as [Rem]
FROM [oms_kl_OS_Sluch] as [hDED]
go

