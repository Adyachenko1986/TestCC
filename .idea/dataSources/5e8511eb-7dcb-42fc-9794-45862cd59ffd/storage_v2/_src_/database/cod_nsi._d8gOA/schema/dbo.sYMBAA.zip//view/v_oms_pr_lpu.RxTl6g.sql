CREATE VIEW [V_oms_pr_LPU] AS SELECT 
[hDED].[pr_LPUID], [hDED].[x_Edition], [hDED].[x_Status], 
(ltrim(rtrim(Fam+' '+Im+' '+Ot))) as [V_FIO], 
[jT_oms_LPU].[M_NAMES] as [V_M_NAMES], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[hDED].[Phone] as [Phone], 
[hDED].[Fam] as [Fam], 
[hDED].[Im] as [Im], 
[hDED].[Ot] as [Ot], 
[hDED].[Email] as [Email], 
[hDED].[DatePlan] as [DatePlan], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_LPU] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

