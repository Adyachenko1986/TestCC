CREATE VIEW [V_stt_TemplateType] AS SELECT 
[hDED].[TemplateTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateTypeID] as [rf_TemplateTypeID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[flags] as [flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[isSimple] as [isSimple]
FROM [stt_TemplateType] as [hDED]
go

