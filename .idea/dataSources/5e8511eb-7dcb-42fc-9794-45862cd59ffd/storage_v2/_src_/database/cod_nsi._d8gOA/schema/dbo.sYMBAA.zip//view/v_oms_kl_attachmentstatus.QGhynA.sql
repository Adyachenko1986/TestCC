CREATE VIEW [V_oms_kl_AttachmentStatus] AS SELECT 
[hDED].[kl_AttachmentStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_kl_AttachmentStatus] as [hDED]
go

