CREATE VIEW [V_stt_ServiceStandart] AS SELECT 
[hDED].[ServiceStandartID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_ServiceMedicalID] as [rf_kl_ServiceMedicalID], 
[hDED].[rf_MedStandartID] as [rf_MedStandartID]
FROM [stt_ServiceStandart] as [hDED]
go

