CREATE VIEW [V_oms_Finl] AS SELECT 
[hDED].[FinlID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[NAME] as [NAME], 
[hDED].[C_FINL] as [C_FINL]
FROM [oms_Finl] as [hDED]
go

