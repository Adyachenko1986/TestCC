CREATE VIEW [V_hlt_mkp_TypeMarker] AS SELECT 
[hDED].[mkp_TypeMarkerID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Name] as [Name], 
[hDED].[DefResult] as [DefResult], 
[hDED].[rf_ResearchTypeParamGUID] as [rf_ResearchTypeParamGUID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_mkp_TypeMarker] as [hDED]
go

