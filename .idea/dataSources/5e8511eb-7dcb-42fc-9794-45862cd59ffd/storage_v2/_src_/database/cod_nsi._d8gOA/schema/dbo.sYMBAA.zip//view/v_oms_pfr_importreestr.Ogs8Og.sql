CREATE VIEW [V_oms_PFR_ImportReestr] AS SELECT 
[hDED].[PFR_ImportReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ImportDate] as [ImportDate], 
[hDED].[ImportReestr_Name] as [ImportReestr_Name]
FROM [oms_PFR_ImportReestr] as [hDED]
go

