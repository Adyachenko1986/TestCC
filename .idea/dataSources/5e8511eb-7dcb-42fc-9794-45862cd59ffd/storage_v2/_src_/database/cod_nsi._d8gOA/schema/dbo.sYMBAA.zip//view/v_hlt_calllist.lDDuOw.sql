CREATE VIEW [V_hlt_CallList] AS SELECT 
[hDED].[CallListID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DoctorVisitTableID] as [rf_DoctorVisitTableID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_ServicePointID] as [rf_ServicePointID], 
[hDED].[VisitStatus] as [VisitStatus], 
[hDED].[TicketNum] as [TicketNum], 
[hDED].[CallDate] as [CallDate], 
[hDED].[Flags] as [Flags]
FROM [hlt_CallList] as [hDED]
go

