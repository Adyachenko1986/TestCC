CREATE VIEW [V_rls_ClsOkdp] AS SELECT 
[hDED].[ClsOkdpID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [rls_ClsOkdp] as [hDED]
go

