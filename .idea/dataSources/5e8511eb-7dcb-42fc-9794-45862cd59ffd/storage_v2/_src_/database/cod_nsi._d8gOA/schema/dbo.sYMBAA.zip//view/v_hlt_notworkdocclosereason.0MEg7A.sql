CREATE VIEW [V_hlt_NotWorkDocCloseReason] AS SELECT 
[hDED].[NotWorkDocCloseReasonID], [hDED].[x_Edition], [hDED].[x_Status], 
(CODE + ' - ' + NAME) as [v_CN], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME]
FROM [hlt_NotWorkDocCloseReason] as [hDED]
go

