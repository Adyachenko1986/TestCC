CREATE VIEW [V_oms_SMO] AS SELECT 
[hDED].[SMOID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_Organisation].[INN] as [V_INN], 
[jT_oms_Organisation].[R_Account] as [V_R_Account], 
[jT_oms_Organisation].[Bank] as [V_Bank], 
[jT_oms_Organisation].[C_Account] as [V_C_Account], 
[jT_oms_Organisation].[BIK_Bank] as [V_BIK_Bank], 
[jT_oms_OKATO].[O_NAME] as [V_O_NAME], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATOID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[Q_OGRN] as [Q_OGRN], 
[hDED].[Q_NAME] as [Q_NAME], 
[hDED].[IM_RUK] as [IM_RUK], 
[hDED].[FAM_RUK] as [FAM_RUK], 
[hDED].[OT_RUK] as [OT_RUK], 
[hDED].[FAM_BUX] as [FAM_BUX], 
[hDED].[IM_BUX] as [IM_BUX], 
[hDED].[OT_BUX] as [OT_BUX], 
[hDED].[TEL] as [TEL], 
[hDED].[FAX] as [FAX], 
[hDED].[E_MAIL] as [E_MAIL], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[ADRES] as [ADRES], 
[hDED].[POST_IDP] as [POST_IDP], 
[hDED].[OKPO] as [OKPO], 
[hDED].[COD] as [COD], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[smocod] as [smocod], 
[hDED].[Code_CMO] as [Code_CMO], 
[hDED].[OtherTerFlag] as [OtherTerFlag]
FROM [oms_SMO] as [hDED]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation] on [jT_oms_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATOID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
go

