CREATE VIEW [V_hlt_DoctorTimeTable] AS SELECT 
[hDED].[DoctorTimeTableID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_HealingRoomID] as [rf_HealingRoomID], 
[hDED].[rf_DocBusyType] as [rf_DocBusyType], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[Begin_Time] as [Begin_Time], 
[hDED].[End_Time] as [End_Time], 
[hDED].[Date] as [Date], 
[hDED].[FlagAccess] as [FlagAccess], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[UGUID] as [UGUID], 
[hDED].[PlanUE] as [PlanUE], 
[hDED].[TTSource] as [TTSource], 
[hDED].[LastStubNum] as [LastStubNum], 
[hDED].[UsedUE] as [UsedUE]
FROM [hlt_DoctorTimeTable] as [hDED]
go

