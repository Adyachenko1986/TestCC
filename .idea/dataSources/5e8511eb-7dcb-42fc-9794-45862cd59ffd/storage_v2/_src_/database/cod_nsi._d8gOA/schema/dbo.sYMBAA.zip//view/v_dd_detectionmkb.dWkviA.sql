CREATE VIEW [V_dd_DetectionMkb] AS SELECT 
[hDED].[DetectionMkbID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DetectionMkb] as [hDED]
go

