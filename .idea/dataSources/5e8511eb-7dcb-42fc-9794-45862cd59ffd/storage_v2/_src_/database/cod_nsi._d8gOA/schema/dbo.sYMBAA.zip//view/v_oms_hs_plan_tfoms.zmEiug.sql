CREATE VIEW [V_oms_hs_plan_tfoms] AS SELECT 
[hDED].[hs_plan_tfomsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[PlanTimeInt] as [PlanTimeInt], 
[hDED].[PlanYear] as [PlanYear], 
[hDED].[Value] as [Value], 
[hDED].[Value_d] as [Value_d]
FROM [oms_hs_plan_tfoms] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
go

