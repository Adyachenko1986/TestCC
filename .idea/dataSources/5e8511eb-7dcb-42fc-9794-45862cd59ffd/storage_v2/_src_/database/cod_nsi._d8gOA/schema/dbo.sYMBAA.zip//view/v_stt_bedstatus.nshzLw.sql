CREATE VIEW [V_stt_BedStatus] AS SELECT 
[hDED].[BedStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_BedStatus] as [hDED]
go

