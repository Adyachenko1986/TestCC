CREATE VIEW [V_hlt_DirectionManipulation] AS SELECT 
[hDED].[DirectionManipulationID], [hDED].[x_Edition], [hDED].[x_Status], 
((select convert(varchar,[hded].DateDirection,104) + ' - ' + [jT_hlt_TypeManipulation].[Name])) as [V_TypeDate], 
(select jt_hlt_MKAB.FAMILY + ' ' + jt_hlt_MKAB.NAME + ' ' + jt_hlt_MKAB.OT) as [V_FIOPat], 
[jT_hlt_MKAB].[NUM] as [V_MKABNum], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_TypeManipulationID] as [rf_TypeManipulationID], 
[jT_hlt_TypeManipulation].[CODE] as [SILENT_rf_TypeManipulationID], 
[hDED].[Num] as [Num], 
[hDED].[DateDirection] as [DateDirection], 
[hDED].[Comment] as [Comment], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [hlt_DirectionManipulation] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_TypeManipulation] as [jT_hlt_TypeManipulation] on [jT_hlt_TypeManipulation].[TypeManipulationID] = [hDED].[rf_TypeManipulationID]
go

