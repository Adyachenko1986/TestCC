CREATE VIEW [V_hlt_NotWorkDocBreakMode] AS SELECT 
[hDED].[NotWorkDocBreakModeID], [hDED].[x_Edition], [hDED].[x_Status], 
(CODE + ' - ' + NAME) as [v_CN], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME]
FROM [hlt_NotWorkDocBreakMode] as [hDED]
go

