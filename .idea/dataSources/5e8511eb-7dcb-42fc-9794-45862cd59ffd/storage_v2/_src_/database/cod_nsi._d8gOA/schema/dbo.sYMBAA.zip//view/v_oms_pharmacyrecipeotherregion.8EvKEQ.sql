CREATE VIEW [V_oms_PharmacyRecipeOtherRegion] AS SELECT 
[hDED].[PharmacyRecipeOtherRegionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_SFOID] as [rf_SFOID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[hDED].[rf_RecipeDefinitionID] as [rf_RecipeDefinitionID], 
[hDED].[rf_PR_LRID] as [rf_PR_LRID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[SERIES_RECIPE] as [SERIES_RECIPE], 
[hDED].[NUM_RECIPE] as [NUM_RECIPE], 
[hDED].[DATE_VR] as [DATE_VR], 
[hDED].[C_OGRN_LPU] as [C_OGRN_LPU], 
[hDED].[PCOD] as [PCOD], 
[hDED].[SS] as [SS], 
[hDED].[SN_POL] as [SN_POL], 
[hDED].[KV_ALL] as [KV_ALL], 
[hDED].[DOZ_LS] as [DOZ_LS], 
[hDED].[DATE_OTP] as [DATE_OTP], 
[hDED].[KO_ALL] as [KO_ALL], 
[hDED].[PRICE] as [PRICE]
FROM [oms_PharmacyRecipeOtherRegion] as [hDED]
go

