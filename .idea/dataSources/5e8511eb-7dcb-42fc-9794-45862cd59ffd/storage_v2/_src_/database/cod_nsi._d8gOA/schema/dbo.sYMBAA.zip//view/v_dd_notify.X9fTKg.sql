CREATE VIEW [V_dd_Notify] AS SELECT 
[hDED].[NotifyID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Status] as [Status], 
[hDED].[Caption] as [Caption], 
[hDED].[Text] as [Text], 
[hDED].[User_ID] as [User_ID]
FROM [dd_Notify] as [hDED]
go

