CREATE VIEW [V_dd_DDStationarInstitution] AS SELECT 
[hDED].[DDStationarInstitutionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_DDScheduleGUID] as [rf_DDScheduleGUID], 
[hDED].[rf_DDStationarInstitutionTypeGUID] as [rf_DDStationarInstitutionTypeGUID], 
[hDED].[rf_DDDepartmentMembershipGUID] as [rf_DDDepartmentMembershipGUID], 
[hDED].[StationarInstitutionName] as [StationarInstitutionName], 
[hDED].[Address] as [Address], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[StationarInstitutionNameOld] as [StationarInstitutionNameOld], 
[hDED].[FAM_RUK] as [FAM_RUK], 
[hDED].[IM_RUK] as [IM_RUK], 
[hDED].[OT_RUK] as [OT_RUK], 
[hDED].[TEL] as [TEL], 
[hDED].[POST_IDP] as [POST_IDP], 
[hDED].[INN] as [INN], 
[hDED].[KPP] as [KPP], 
[hDED].[OGRN] as [OGRN]
FROM [dd_DDStationarInstitution] as [hDED]
go

