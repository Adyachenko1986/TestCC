CREATE VIEW [V_oms_ServiceMedicalParam] AS SELECT 
[hDED].[ServiceMedicalParamID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_ParamID] as [rf_ParamID], 
[jT_oms_Param].[Name] as [SILENT_rf_ParamID], 
[hDED].[StringForUser] as [StringForUser], 
[hDED].[Doc] as [Doc], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[ServiceMedicalParamGUID] as [ServiceMedicalParamGUID]
FROM [oms_ServiceMedicalParam] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_Param] as [jT_oms_Param] on [jT_oms_Param].[ParamID] = [hDED].[rf_ParamID]
go

