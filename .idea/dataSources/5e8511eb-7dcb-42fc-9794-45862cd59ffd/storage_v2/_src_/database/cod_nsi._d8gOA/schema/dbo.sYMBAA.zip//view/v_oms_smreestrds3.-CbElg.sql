CREATE VIEW [V_oms_SMReestrDS3] AS SELECT 
[hDED].[SMReestrDS3ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[jT_oms_SMReestrSluch].[IDCase] as [SILENT_rf_SMReestrSluchID], 
[hDED].[DS3] as [DS3]
FROM [oms_SMReestrDS3] as [hDED]
INNER JOIN [oms_SMReestrSluch] as [jT_oms_SMReestrSluch] on [jT_oms_SMReestrSluch].[SMReestrSluchID] = [hDED].[rf_SMReestrSluchID]
go

