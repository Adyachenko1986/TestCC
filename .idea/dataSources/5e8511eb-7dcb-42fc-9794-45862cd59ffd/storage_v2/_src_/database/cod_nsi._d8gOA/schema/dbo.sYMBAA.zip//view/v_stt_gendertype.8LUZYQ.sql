CREATE VIEW [V_stt_GenderType] AS SELECT 
[hDED].[GenderTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Gender] as [Gender], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_GenderType] as [hDED]
go

