CREATE VIEW [V_oms_SMExpert] AS SELECT 
[hDED].[SMExpertID], [hDED].[x_Edition], [hDED].[x_Status], 
((case when [jT_oms_SMExpertType].SMExpertTypeID>0 then [jT_oms_SMExpertType].name else 
'экспертиза '  end+'. '+[jT_oms_SMReestr].[V_SMReestr] 
)) as [V_SMExpert], 
((((select FIO from x_User where UserId = rf_UserID)))) as [V_FIOUser], 
[hDED].[rf_SMReestrID] as [rf_SMReestrID], 
[jT_oms_SMReestr].[V_SMReestr] as [SILENT_rf_SMReestrID], 
[hDED].[rf_SMExpertTypeID] as [rf_SMExpertTypeID], 
[jT_oms_SMExpertType].[Name] as [SILENT_rf_SMExpertTypeID], 
[hDED].[rf_MTReestrID] as [rf_MTReestrID], 
[jT_oms_MTReestr].[FileName] as [SILENT_rf_MTReestrID], 
[hDED].[Date] as [Date], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[BadSum] as [BadSum], 
[hDED].[DateIn] as [DateIn], 
[hDED].[SumV] as [SumV], 
[hDED].[KolV] as [KolV], 
[hDED].[KolSank] as [KolSank], 
[hDED].[Description] as [Description], 
[hDED].[Num] as [Num]
FROM [oms_SMExpert] as [hDED]
INNER JOIN [V_oms_SMReestr] as [jT_oms_SMReestr] on [jT_oms_SMReestr].[SMReestrID] = [hDED].[rf_SMReestrID]
INNER JOIN [oms_SMExpertType] as [jT_oms_SMExpertType] on [jT_oms_SMExpertType].[SMExpertTypeID] = [hDED].[rf_SMExpertTypeID]
INNER JOIN [oms_MTReestr] as [jT_oms_MTReestr] on [jT_oms_MTReestr].[MTReestrID] = [hDED].[rf_MTReestrID]
go

