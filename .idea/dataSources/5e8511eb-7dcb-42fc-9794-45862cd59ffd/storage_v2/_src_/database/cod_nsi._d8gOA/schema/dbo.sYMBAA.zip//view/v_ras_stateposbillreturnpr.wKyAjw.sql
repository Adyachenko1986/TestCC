CREATE VIEW [V_ras_StatePosBillReturnPr] AS SELECT 
[hDED].[StatePosBillReturnPrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [ras_StatePosBillReturnPr] as [hDED]
go

