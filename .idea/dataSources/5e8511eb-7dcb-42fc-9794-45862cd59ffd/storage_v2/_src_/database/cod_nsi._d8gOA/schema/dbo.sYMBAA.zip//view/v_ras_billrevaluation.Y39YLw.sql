CREATE VIEW [V_ras_BillRevaluation] AS SELECT 
[hDED].[BillRevaluationID], [hDED].[HostBillRevaluationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[rf_ResponsibleID] as [rf_ResponsibleID], 
[hDED].[rf_ResponsibleIDHost] as [rf_ResponsibleIDHost], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[hDED].[rf_PeriodIDHost] as [rf_PeriodIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_DocumentJournalID] as [rf_DocumentJournalID], 
[hDED].[rf_DocumentJournalIDHost] as [rf_DocumentJournalIDHost], 
[hDED].[rf_StateBillRevaluationID] as [rf_StateBillRevaluationID], 
[hDED].[rf_BillRevaluationID] as [rf_BillRevaluationID], 
[hDED].[rf_BillRevaluationIDHost] as [rf_BillRevaluationIDHost], 
[hDED].[NUM] as [NUM], 
[hDED].[DATE] as [DATE], 
[hDED].[Date_OP] as [Date_OP], 
[hDED].[Author] as [Author], 
[hDED].[Note] as [Note], 
[hDED].[SummaOld] as [SummaOld], 
[hDED].[Summa] as [Summa], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[FLAGS] as [FLAGS]
FROM [ras_BillRevaluation] as [hDED]
go

